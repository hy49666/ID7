'use strict';

const fs = require('fs');
const https = require('https');
const path = require('path');
const { execFile } = require('child_process');
const { Transform } = require('stream');
const { pipeline } = require('stream/promises');
const { promisify } = require('util');

const runDecoder = promisify(execFile);
const maxDownloadBytes = 128 * 1024 * 1024;
const maxOutputBytes = 32 * 1024 * 1024;

function musicUrl(raw) {
    const url = new URL(raw);
    if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.port ||
        !/^[a-z0-9.-]+\.music\.(126|163)\.net$/i.test(url.hostname)) {
        throw Error('Unsupported NetEase music URL');
    }
    url.protocol = 'https:';
    return url;
}

async function download(raw, destination, signal, validateUrl, redirects = 0) {
    const url = validateUrl(raw);
    const response = await new Promise((resolve, reject) => {
        const request = https.get(url, { signal }, resolve);
        request.setTimeout(15000, () => request.destroy(Error('Music download timed out')));
        request.once('error', reject);
    });
    if ([301, 302, 303, 307, 308].includes(response.statusCode) && response.headers.location && redirects < 3) {
        response.destroy();
        return download(new URL(response.headers.location, url), destination, signal, validateUrl, redirects + 1);
    }
    if (response.statusCode !== 200 || Number(response.headers['content-length']) > maxDownloadBytes) {
        response.destroy();
        throw Error('Music download unavailable');
    }
    let received = 0;
    const limit = new Transform({
        transform(chunk, encoding, callback) {
            received += chunk.length;
            if (received > maxDownloadBytes) return callback(Error('Music download exceeds limit'));
            callback(null, chunk);
        }
    });
    await pipeline(response, limit, fs.createWriteStream(destination, { flags: 'wx' }), { signal });
}

async function prepareNativeAudio({ runtime, ffmpeg, url, signal, metadata = {}, validateUrl = musicUrl, expectedDurationMs }) {
    const folder = await fs.promises.mkdtemp(path.join(runtime, 'native-audio-'));
    const input = path.join(folder, 'input');
    const output = path.join(folder, 'audio.m4a');
    try {
        const [, { tags = {}, cover }] = await Promise.all([download(url, input, signal, validateUrl), metadata]);
        const tagArguments = Object.entries(tags).flatMap(([name, value]) =>
            typeof value === 'string' && value.trim()
                ? ['-metadata', name + '=' + value.replace(/\0/g, '').trim().slice(0, 512)] : []);
        const jpeg = cover && cover.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff]));
        const png = cover && cover.subarray(0, 8).equals(Buffer.from('89504e470d0a1a0a', 'hex'));
        const picture = jpeg || png ? path.join(folder, jpeg ? 'cover.jpg' : 'cover.png') : null;
        if (picture) await fs.promises.writeFile(picture, cover, { flags: 'wx' });
        const convert = image => runDecoder(ffmpeg, [
            '-nostdin', '-hide_banner', '-loglevel', 'error', '-protocol_whitelist', 'file',
            ...(expectedDurationMs ? ['-xerror', '-progress', 'pipe:1'] : []),
            '-format_whitelist', 'mp3,flac,aac,mov,mp4,m4a,3gp,3g2,mj2,ogg,wav,matroska,webm',
            '-i', input,
            ...(image ? ['-f', 'image2', '-pattern_type', 'none', '-i', image] : []),
            '-map', '0:a:0',
            ...(image ? ['-map', '1:v:0', '-c:v', 'copy', '-disposition:v:0', 'attached_pic'] : []),
            '-map_metadata', '-1', '-map_chapters', '-1', ...tagArguments,
            '-c:a', 'aac', '-profile:a', 'aac_low', '-ar', '44100', '-ac', '2', '-b:a', '128k',
            '-movflags', '+faststart', '-fs', String(maxOutputBytes), output
        ], { signal, timeout: 90000, windowsHide: true });
        let result;
        try {
            result = await convert(picture);
        } catch (error) {
            if (!picture || signal.aborted) throw error;
            await fs.promises.rm(output, { force: true });
            result = await convert(null);
        }
        if (expectedDurationMs) {
            const elapsed = Array.from(result.stdout.matchAll(/^out_time_us=(\d+)$/gm), match => Number(match[1])).pop() / 1000;
            if (!Number.isFinite(elapsed) || Math.abs(elapsed - expectedDurationMs) > Math.max(1800, expectedDurationMs * 0.015)) {
                throw Object.assign(Error('Audio duration does not match the full track'), { code: 'INCOMPLETE_AUDIO' });
            }
        }
        const stat = await fs.promises.stat(output);
        if (!stat.size || stat.size >= maxOutputBytes) throw Error('Invalid converted music size');
        return { folder, output, size: stat.size };
    } catch (error) {
        await fs.promises.rm(folder, { recursive: true, force: true });
        throw error;
    }
}

module.exports = { prepareNativeAudio };
