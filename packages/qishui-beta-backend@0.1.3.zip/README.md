# 汽水音乐 Beta 电脑端 API

需要 Node.js 22 或更新版本。完整音频转换还需要 FFmpeg，可在 PATH 中提供 ffmpeg，也可用环境变量 QISHUI_FFMPEG 指定可执行文件。

在解压目录运行：

```sh
node qishui-bridge.js
```

电脑后端默认监听 127.0.0.1:33633 。访问 http://127.0.0.1:33633/health 检查运行状态。对于已启用 SSH 的自有 ID7 主机，使用已验证的 SSH 主机身份建立转发，例如：

```sh
ssh -NT -o ExitOnForwardFailure=yes -R 127.0.0.1:33632:127.0.0.1:33633 用户名@车机地址
```

安装汽水音乐 Beta 后，用应用登录页指定的手机客户端扫码授权。电脑后端使用 qishui-runtime 目录保存本地帐号会话，每位使用者应运行自己的后端实例。

已验证部分歌曲取得完整音频并传输至测试台架。整曲可用性取决于账号及上游返回。Beta 版本的个人歌单、画面和音频体验在不同设备上仍需验证。

PowerBy 小白科技杂物社

FREE APPS IF PAID PLEASE RETURN

免费应用请勿付费

- [车机 API 实现](https://github.com/GSQZ/qishui-music-api)
- [网页 API 实现](https://github.com/guowenye/qishui-api)
