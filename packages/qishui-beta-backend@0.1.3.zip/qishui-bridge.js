'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const { pipeline } = require('stream/promises');
const { QishuiClient } = require('./qishui-api-upstream/src/qishuiClient');
const { normalizeTrack } = require('./qishui-api-upstream/src/normalizers');
const { prepareNativeAudio } = require('./netease-api/native-audio');
const {randomBytes}=require('crypto');
const {createQishuiApi,createQishuiDeviceId}=require('./qishui-car-api');
const client = new QishuiClient({ timeoutMs: 9000 });
const runtime = process.env.QISHUI_RUNTIME_DIR || path.join(__dirname, 'qishui-runtime');
const codes = new Map();
const recommendedPlaylists = new Map();
const playlistOwners = new Map();
const likes = '99999999999999999999';
let audioRequests = 0;
let latestScan = null;
fs.mkdirSync(runtime, { recursive:true });
const accountFile=path.join(runtime,'car-account.json');
let saved={deviceId:createQishuiDeviceId(),key:null,credential:null};
if (fs.existsSync(accountFile)) saved=JSON.parse(fs.readFileSync(accountFile,'utf8'));
let revision=0;
function saveAccount(next) {
    const tmp=accountFile+'.tmp';
    fs.writeFileSync(tmp,JSON.stringify(next),{mode:0o600});
    fs.renameSync(tmp,accountFile);
    saved=next;
    revision++;
}
const carApi=createQishuiApi({
    deviceId:saved.deviceId,log:()=>{},
    sessions:{
        deviceId:saved.deviceId,get revision(){return revision;},get:()=>saved.credential,
        set:credential=>saveAccount({...saved,key:saved.credential?.userId===credential.userId && saved.key
            ?saved.key:'car-'+randomBytes(24).toString('hex'),credential}),
        clear:()=>saveAccount({...saved,key:null,credential:null})
    }
});
async function car(operation,args) {
    const result=await carApi.request(operation,args);
    if (!result.ok) throw Object.assign(fault(result.error.code==='auth-required'?301:502,'汽水车机接口未完成请求'),
        {upstreamCode:result.error.upstreamCode});
    return result.data;
}
const carAuthorized=key=>Boolean(saved.key && key===saved.key);

function carTrack(value) {
    const base=value.base_info||{};
    const related=value.related_info||{};
    return {id:value.id,name:base.name||'',dt:Number(base.duration_ms)||0,
        al:{id:related.album_link?.id,name:related.album_link?.name||'',
            picUrl:carCoverUrl(value.display_info?.cover_url)},
        ar:(related.artist_links||[]).map(item=>({id:item.id,name:item.name||item.simple_display_name||''}))};
}

function carCoverUrl(coverInfo) {
    const base=coverInfo?.urls?.[0];
    if (typeof base!=='string') return '';
    if (base.endsWith('/img/') && coverInfo.uri && /^tplv-[a-z0-9]+$/i.test(coverInfo.template_prefix||'')) {
        return base+coverInfo.uri+'~'+coverInfo.template_prefix+'-resize:200:200.jpeg';
    }
    return base+(coverInfo.uri||'');
}

function pollCode(value) {
    if (value.poll && (value.polling || Date.now()-value.pollTime<2500)) return value.poll;
    value.pollTime=Date.now();
    value.polling=true;
    value.poll=car('login_qr_check',{key:value.key}).then(answer=>{
        const result={code:{waiting:801,scanned:802,confirmed:803,expired:800,error:800}[answer.state]||802,stage:answer.state};
        if (result.code===803) result.sessionid=saved.key;
        const stage=result.stage || 'session-received';
        if (stage!==value.lastStage) {
            value.lastStage=stage;
            latestScan={stage,time:Date.now(),upstreamError:result.upstreamError};
        }
        if (stage==='rate-limited') value.pollTime=Date.now()+2500;
        return result;
    }).finally(()=>{value.polling=false;});
    return value.poll;
}

function observeScan(value) {
    if (value.observer) return;
    value.observer=setInterval(async()=>{
        if (Date.now()>=value.until) {
            clearInterval(value.observer);
            return;
        }
        try {
            const result=await pollCode(value);
            if (result.code===800 || result.code===803 || result.stage==='second-verification') {
                clearInterval(value.observer);
            }
        } catch (_) {
            latestScan={stage:'poll-failed',time:Date.now()};
        }
    },3000);
    value.observer.unref();
}

function fault(code, message) {
    return Object.assign(Error(message), { responseCode:code });
}

function id(value) {
    if (!/^\d{1,20}$/.test(String(value || ''))) throw fault(400,'汽水歌曲或歌单编号无效');
    return String(value);
}

function session(value) {
    return typeof value==='string' && /^[A-Za-z0-9._-]{8,512}$/.test(value) ? value : undefined;
}

function album(value = {}) {
    return { id:value.id, name:value.name || '', picUrl:value.cover_url || '' };
}

function track(value) {
    return { id:value.id, name:value.name, dt:Number(value.duration)||0,
        al:album(value.album || {}), ar:(value.artists || []).map(a=>({id:a.id,name:a.name,picUrl:a.avatar_url})) };
}

function list(value, userId) {
    return { id:value.id, name:value.title, coverImgUrl:value.cover_url, trackCount:value.count_tracks, userId };
}

function checked(result) {
    const raw=result.upstream || result.raw || {};
    if (Number(raw.status_code || raw.status_info?.status_code || 0) !== 0) {
        throw fault(502,'汽水上游未授权或拒绝了本次查询');
    }
    return result;
}

async function profile(sessionid) {
    if (!sessionid) throw fault(301,'请用抖音扫码登录汽水音乐');
    if (carAuthorized(sessionid)) {
        const user=await car('login_status');
        if (!user?.id) throw fault(301,'汽水登录会话已失效');
        return {userId:user.id,nickname:user.nickname};
    }
    if (sessionid.startsWith('car-')) throw fault(301,'汽水登录会话已失效');
    const result=checked(await client.authMe({sessionid}));
    if (!result.profile?.id) throw fault(301,'汽水登录会话已失效');
    return {userId:result.profile.id,nickname:result.profile.nickname};
}

async function collections(sessionid) {
    return checked(await client.meCollectionMixed({sessionid})).mixed_collections;
}

function restrictedUrl(raw, host) {
    const url=new URL(raw);
    if (url.protocol!=='https:' || url.username || url.password || url.port || !host.test(url.hostname)) {
        throw fault(403,'汽水媒体地址未获支持');
    }
    return url;
}

async function cover(raw, signal) {
    const url=restrictedUrl(raw,/^p\d+-luna\.douyinpic\.com$/i);
    const response=await fetch(url,{redirect:'error',signal:signal || AbortSignal.timeout(7000)});
    if (!response.ok || !/^image\/(jpeg|png)/i.test(response.headers.get('content-type')||'')) {
        throw fault(404,'汽水封面不可用');
    }
    const chunks=[];
    let length=0;
    for await (const chunk of response.body) {
        length+=chunk.length;
        if (length>512*1024) throw fault(413,'汽水封面过大');
        chunks.push(chunk);
    }
    return Buffer.concat(chunks);
}

async function playback(args,res) {
    if (audioRequests>=2) throw fault(503,'汽水播放服务正忙');
    const trackId=id(args.id);
    const controller=new AbortController();
    const abort=()=>controller.abort();
    const timer=setTimeout(abort,110000);
    res.once('close',abort);
    audioRequests++;
    let prepared;
    try {
        const token=session(args.cookie);
        let url, duration, tags, imageUrl;
        if (token?.startsWith('car-') && !carAuthorized(token)) throw fault(301,'汽水登录会话已失效');
        const native=carAuthorized(token) ? await carApi.request('audio',{id:trackId,quality:'standard'}) : null;
        if (native?.ok && !native.data.preview) {
            const song=carTrack(await car('song_detail',{id:trackId}));
            url=native.data.url;
            duration=song.dt;
            tags={title:song.name,artist:song.ar.map(artist=>artist.name).join(' / '),album:song.al.name};
            imageUrl=song.al.picUrl;
        } else {
            const stream=await client.downloadUrl({track_id:trackId,sessionid:carAuthorized(token)?undefined:token,include_raw:true});
            if (stream.track_id!==trackId || stream.has_spade_a || stream.play_auth) throw fault(403,'汽水未提供可验证的明文整曲');
            const item=normalizeTrack(stream.raw?.seo_track?.track || stream.raw?.track);
            url=stream.audio_url;
            duration=Number(item?.duration);
            tags={title:stream.name,artist:stream.artists.map(artist=>artist.name).join(' / '),album:stream.album?.name};
            imageUrl=item?.album?.cover_url;
        }
        if (!Number.isFinite(duration) || duration<=0) {
            throw fault(403,'汽水未提供可验证的明文整曲');
        }
        const image=imageUrl ? await cover(imageUrl,AbortSignal.timeout(4000)).catch(()=>null) : null;
        const ffmpegConfig=path.join(__dirname,'netease-api','ffmpeg-path.json');
        const ffmpeg=process.env.QISHUI_FFMPEG || (fs.existsSync(ffmpegConfig) ? require(ffmpegConfig).path : 'ffmpeg');
        prepared=await prepareNativeAudio({runtime,ffmpeg,url,signal:controller.signal,
            metadata:{tags,cover:image},expectedDurationMs:duration,
            validateUrl:raw=>{
                try { return restrictedUrl(raw,/^[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:douyinvod\.com|365yg\.com)$/i); }
                catch (_) { throw fault(502,'汽水音频地址未获支持'); }
            }});
        res.setHeader('Content-Type','audio/mp4');
        res.setHeader('Content-Length',prepared.size);
        await pipeline(fs.createReadStream(prepared.output),res,{signal:controller.signal});
    } catch (error) {
        if (error.code==='INCOMPLETE_AUDIO') throw fault(403,'汽水本次只返回试听或不完整音频');
        throw error;
    } finally {
        clearTimeout(timer);
        res.removeListener('close',abort);
        audioRequests--;
        if (prepared) await fs.promises.rm(prepared.folder,{recursive:true,force:true});
    }
}

async function playlistPage(args, sessionid) {
    const playlistId=id(args.id);
    const offset=Math.min(500,Math.max(0,Number(args.offset)||0));
    const limit=Math.min(50,Math.max(1,Number(args.limit)||20));
    if (playlistId===likes) {
        if (carAuthorized(sessionid)) {
            const liked=await car('liked_songs');
            const songs=liked.tracks.slice(offset,offset+limit).map(carTrack);
            return {songs,playlist:{trackCount:liked.total}};
        }
        const songs=(await collections(sessionid)).map(item=>item.track).filter(Boolean);
        return {songs:songs.slice(offset,offset+limit).map(track),playlist:{trackCount:songs.length}};
    }
    if (carAuthorized(sessionid) && !recommendedPlaylists.has(playlistId)) {
        let page;
        try { page=await car('playlist_tracks',{id:playlistId,limit,offset,ownerId:playlistOwners.get(playlistId)}); }
        catch (error) { if (error.upstreamCode!=='28001035' || playlistOwners.has(playlistId)) throw error; }
        if (page) {
            const end=offset+page.items.length;
            const reported=Number(page.collection?.resource_cnt?.track_cnt)||0;
            const total=page.total ?? Math.max(end+Number(page.hasMore),reported);
            return {songs:page.items.map(carTrack),playlist:{trackCount:total}};
        }
    }
    const context=sessionid&&!sessionid.startsWith('car-')?{cookie:'sessionid='+sessionid}:{};
    const songs=[];
    let cursor, page;
    do {
        page=checked(await client.playlistDetail({playlist_id:playlistId,playlist_type:recommendedPlaylists.get(playlistId),count:limit,cursor},context));
        songs.push(...page.media_resources.map(item=>item.track).filter(Boolean));
        const next=page.next_cursor;
        if (!next || next===cursor || !page.media_resources.length) break;
        cursor=next;
    } while (songs.length<offset+limit);
    return {songs:songs.slice(offset,offset+limit).map(track),playlist:{trackCount:page.playlist?.count_tracks||songs.length}};
}

async function route(url,args) {
    const sessionid=session(args.cookie);
    const context=sessionid&&!sessionid.startsWith('car-')?{cookie:'sessionid='+sessionid}:{};
    switch (url) {
    case '/login/qr/key': {
        const now=Date.now();
        for (const [key,value] of codes) {
            if (value.until>now) continue;
            codes.delete(key);
            clearInterval(value.observer);
        }
        if (codes.size>=24) throw fault(503,'扫码请求过多');
        for (const entry of codes.values()) clearInterval(entry.observer);
        codes.clear();
        const {key}=await car('login_qr_key');
        const image=await car('login_qr_create',{key});
        codes.set(key,{image:image.imageUrl,key,until:Date.now()+180000});
        latestScan = {stage:'issued',time:Date.now()};
        return {data:{unikey:key}};
    }
    case '/login/qr/create': {
        const value=codes.get(args.key);
        if (!value || value.until<=Date.now()) throw fault(410,'二维码已过期');
        if (args.qrimg===true) observeScan(value);
        return {data:{qrurl:'https://music.douyin.com/',qrimg:value.image}};
    }
    case '/login/qr/check': {
        const value=codes.get(args.key);
        if (!value || value.until<=Date.now()) return {code:800};
        const result=await pollCode(value);
        if (result.code===803) {
            if (!carAuthorized(result.sessionid)) throw fault(301,'汽水登录会话已失效');
            codes.delete(args.key);
            clearInterval(value.observer);
            return {code:803,cookie:result.sessionid};
        }
        if (result.code===800) {
            codes.delete(args.key);
            clearInterval(value.observer);
        }
        return {code:result.code};
    }
    case '/login/status': return {data:{profile:await profile(sessionid)}};
    case '/personalized':
    case '/recommend/resource': {
        const recommendations=checked(await client.recommendPlaylists({count:12},context)).playlists;
        if (recommendedPlaylists.size>256) recommendedPlaylists.clear();
        for (const item of recommendations) recommendedPlaylists.set(item.id,item.type);
        const values=recommendations.map(v=>list(v));
        return {result:values,recommend:values};
    }
    case '/user/playlist': {
        const user=await profile(sessionid);
        if (carAuthorized(sessionid)) {
            const offset=Math.max(0,Number(args.offset)||0);
            const page=await car('user_playlists',{limit:offset?50:49,offset:offset?offset-1:0});
            for (const item of page.items) {
                const owner=item.base_info.owner_id || (item.isOwned?user.userId:null);
                if (owner) playlistOwners.set(String(item.base_info.id),String(owner));
            }
            const playlist=page.items.map(item=>({id:String(item.base_info.id),name:item.base_info.title||item.base_info.name||'',
                coverImgUrl:carCoverUrl(item.display_info?.url_cover),
                trackCount:item.resource_cnt?.track_cnt,userId:item.isOwned?user.userId:''}));
            if (!offset) playlist.unshift({id:likes,name:'我喜欢的音乐',userId:user.userId,specialType:5,
                trackCount:(await car('liked_songs')).total});
            return {playlist,more:page.hasMore};
        }
        if (Number(args.offset)>0) return {playlist:[],more:false};
        const [personal,saved]=await Promise.all([client.mePlaylists({sessionid}),collections(sessionid)]);
        const owned=checked(personal).playlists.map(v=>list(v,user.userId));
        const seen=new Set(owned.map(p=>p.id));
        const other=saved.filter(x=>x.playlist && !seen.has(x.playlist.id)).map(x=>list(x.playlist,''));
        const favorite={id:likes,name:'我喜欢的音乐',userId:user.userId,specialType:5,trackCount:saved.filter(x=>x.track).length};
        return {playlist:[favorite,...owned,...other],more:false};
    }
    case '/likelist': return {ids:carAuthorized(sessionid)?(await car('liked_songs')).ids:
        (await collections(sessionid)).filter(x=>x.track).map(x=>x.track.id)};
    case '/playlist/track/all': return playlistPage(args,sessionid);
    case '/playlist/detail': return playlistPage({...args,limit:1},sessionid);
    case '/cloudsearch': {
        const keyword=String(args.keywords||'').trim().slice(0,100);
        const native=await carApi.request('search',{query:keyword,limit:Math.min(30,Number(args.limit)||20),offset:Number(args.offset)||0});
        if (native.ok) return {result:{songs:native.data.items.map(carTrack)}};
        const result=checked(await client.searchMixed({keyword,count:Math.min(30,Number(args.limit)||20),offset:Number(args.offset)||0},context));
        if (!result.tracks.length && !Object.keys(result.upstream||{}).length) throw fault(502,'汽水搜索服务未返回有效数据');
        return {result:{songs:result.tracks.map(track)}};
    }
    case '/song/detail': {
        const info=await client.songDetail({track_id:id(args.ids)},context);
        const raw=normalizeTrack(info.raw?.seo_track?.track||info.raw?.track);
        return {songs:raw?[track(raw)]:[]};
    }
    case '/lyric': return {lrc:{lyric:(await client.lyric({track_id:id(args.id)},context)).lrc||''}};
    case '/cover': return {image:(await cover(args.url)).toString('base64')};
    case '/playlist/catlist': return {sub:[]};
    case '/song/url/v1': return {data:[]};
    default: throw fault(404,'汽水当前未接入此操作');
    }
}

http.createServer(async (req,res)=>{
    res.setHeader('Cache-Control','no-store');
    res.setHeader('Content-Type','application/json; charset=utf-8');
    if (req.method==='GET' && req.url==='/health') return res.end(JSON.stringify({code:200,service:'jackie-qishui-api'}));
    if (req.method==='GET' && req.url==='/scan-status') return res.end(JSON.stringify(latestScan));
    try {
        if (req.method!=='POST') throw fault(404,'接口不存在');
        const chunks=[];
        let bytes=0;
        for await (const chunk of req) {
            bytes+=chunk.length;
            if (bytes>65536) throw fault(413,'请求过大');
            chunks.push(chunk);
        }
        let args;
        try { args=JSON.parse(Buffer.concat(chunks).toString('utf8')); }
        catch (_) { throw fault(400,'请求 JSON 无效'); }
        if (!args || Array.isArray(args) || typeof args!=='object') throw fault(400,'请求必须为对象');
        if (req.url==='/audio/m4a') return await playback(args,res);
        const value=await route(req.url,args);
        res.end(JSON.stringify({code:200,...value}));
    } catch (error) {
        if (res.headersSent || res.destroyed) return;
        const code=error.responseCode || 502;
        res.statusCode=req.url==='/audio/m4a' ? (code===301?401:code) : 200;
        res.end(JSON.stringify({code,message:error.responseCode?error.message:'汽水音乐上游请求失败'}));
    }
}).listen(Number(process.env.QISHUI_BRIDGE_PORT||33633),'127.0.0.1');
