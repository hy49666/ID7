/**
 * PLEASE NOTE: THIS IS A GENERATED FILE!
 * Generation date: Fri Jul 26 09:18:34 UTC 2019
 *
 * ConnectedMusicProxy, generated from the corresponding interface description.
 */
(function (undefined){
	/**
	 * @name ConnectedMusicProxy
	 * @constructor
	 *
	 * @classdesc
	 * <br/>Generation date: Fri Jul 26 09:18:34 UTC 2019
	 * <br/><br/>
	 * ConnectedMusicProxy, generated from the corresponding interface description.
	 *
	 * @param {object} settings the settings object for this function call
	 * @param {String} settings.domain the domain name //TODO: check do we need this?
	 * @param {String} settings.joynrName the interface name //TODO: check do we need this?
	 *
	 * @param {Object} settings.discoveryQos the Quality of Service parameters for arbitration
	 * @param {Number} settings.discoveryQos.discoveryTimeoutMs for rpc calls to wait for arbitration to finish.
	 * @param {String} settings.discoveryQos.arbitrationStrategy Strategy for choosing the appropriate service-provider from the list returned by the capabilities directory
	 * @param {Number} settings.discoveryQos.cacheMaxAgeMs Maximum age of entries in the localCapabilitiesDirectory. If this value filters out all entries of the local capabilities directory a lookup in the global capabilitiesDirectory will take place.
	 * @param {Boolean} settings.discoveryQos.discoveryScope If localOnly is set to true, only local providers will be considered.
	 * @param {Object} settings.discoveryQos.additionalParameters a map holding additional parameters in the form of key value pairs in the javascript object, e.g.: {"myKey": "myValue", "myKey2": 5}
	 *
	 * @param {object} settings.messagingQos the Quality of Service parameters for messaging
	 * @param {Number} settings.messagingQos.ttl Roundtrip timeout for rpc requests.

	 * @param {Number} settings.dependencies instances of the internal objects needed by the proxy to interface with joynr
	 * @param {Number} settings.proxyElementTypes constructors for attribute, method and broadcasts, used to create the proxy's elements
	 *
	 * @returns {ConnectedMusicProxy} a ConnectedMusicProxy object to access other providers
	 */
	var ConnectedMusicProxy = function ConnectedMusicProxy(
		settings) {
		if (!(this instanceof ConnectedMusicProxy)) {
			// in case someone calls constructor without new keyword (e.g. var c = Constructor({..}))
			return new ConnectedMusicProxy(
				settings);
		}

		// generated package name
		this.settings = settings || {};

		/**
		 * @name ConnectedMusicProxy#loggedIn
		 * @summary The loggedIn attribute is GENERATED FROM THE INTERFACE DESCRIPTION
		*/
		this.loggedIn = new settings.proxyElementTypes.ProxyAttribute(this, settings, "loggedIn", "Boolean","NOTIFYREAD");
		/**
		 * @name ConnectedMusicProxy#shuffle
		 * @summary The shuffle attribute is GENERATED FROM THE INTERFACE DESCRIPTION
		*/
		this.shuffle = new settings.proxyElementTypes.ProxyAttribute(this, settings, "shuffle", "Boolean","NOTIFYREAD");

		/**
		 * @function ConnectedMusicProxy#setExModes
		 * @summary The setExModes operation is GENERATED FROM THE INTERFACE DESCRIPTION
		 * <br/><br/>Method to start playback by C-Music
		 *
		 * @param {Object} settings the arguments object for this function call
		 * @param {Exmode} settings.exmode -
		 * @param {Boolean} settings.hmiExpected -
		 */
		this.setExModes = new settings.proxyElementTypes.ProxyOperation(this, settings, "setExModes", [
			{
				inputParameter: [
				{
					name : "exmode",
					type : "joynr.de.bmw.infotainment.telematic.applications.ConnectedMusicTypes.Exmode",
					javascriptType : "joynr.de.bmw.infotainment.telematic.applications.ConnectedMusicTypes.Exmode"
				},
				{
					name : "hmiExpected",
					type : "Boolean",
					javascriptType : "boolean"
				}
				],
				outputParameter: [
				],
				fireAndForget: false
			}
		]).buildFunction();
		/**
		 * @function ConnectedMusicProxy#setShuffle
		 * @summary The setShuffle operation is GENERATED FROM THE INTERFACE DESCRIPTION
		 *
		 * @param {Object} settings the arguments object for this function call
		 * @param {Boolean} settings.shuffleEnabled -
		 */
		this.setShuffle = new settings.proxyElementTypes.ProxyOperation(this, settings, "setShuffle", [
			{
				inputParameter: [
				{
					name : "shuffleEnabled",
					type : "Boolean",
					javascriptType : "boolean"
				}
				],
				outputParameter: [
				],
				fireAndForget: false
			}
		]).buildFunction();


		Object.defineProperty(this, "interfaceName", {
			value: "de/bmw/infotainment/telematic/applications/ConnectedMusic"
		});
	};

	/**
	 * @name ConnectedMusicProxy#MAJOR_VERSION
	 * @constant {Number}
	 * @default 2
	 * @summary The MAJOR_VERSION of the proxy is GENERATED FROM THE INTERFACE DESCRIPTION
	 */
	Object.defineProperty(ConnectedMusicProxy, 'MAJOR_VERSION', { value: 2});
	/**
	 * @name ConnectedMusicProxy#MINOR_VERSION
	 * @constant {Number}
	 * @default 1
	 * @summary The MINOR_VERSION of the proxy is GENERATED FROM THE INTERFACE DESCRIPTION
	 */
	Object.defineProperty(ConnectedMusicProxy, 'MINOR_VERSION', { value: 1});

	ConnectedMusicProxy.getUsedDatatypes = function getUsedDatatypes(){
		return [
			"joynr.de.bmw.infotainment.telematic.applications.ConnectedMusicTypes.Exmode"
		];
	};

	require("../../../../../../joynr/de/bmw/infotainment/telematic/applications/ConnectedMusicTypes/Exmode");
	require("../../../../../../joynr/de/bmw/infotainment/telematic/applications/ConnectedMusic/SetExModesErrorEnum");
	module.exports = ConnectedMusicProxy;
})();
