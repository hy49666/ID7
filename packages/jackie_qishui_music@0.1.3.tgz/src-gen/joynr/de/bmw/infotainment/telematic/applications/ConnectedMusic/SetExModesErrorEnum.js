/**
 * This is the generated enum type SetExModesErrorEnum: DOCS GENERATED FROM INTERFACE DESCRIPTION
 * Generation date: Fri Jul 26 09:18:34 UTC 2019
 */
(function(undefined) {

	/**
	 * @namespace SetExModesErrorEnum
	 * @classdesc
	 * This is the generated enum type SetExModesErrorEnum: DOCS GENERATED FROM INTERFACE DESCRIPTION
	 * <br/>Generation date: Fri Jul 26 09:18:34 UTC 2019
	 *
	 * @returns {SetExModesErrorEnum} a new instance of a SetExModesErrorEnum
	 */
	var SetExModesErrorEnum = function SetExModesErrorEnum(settings){
		if (!(this instanceof SetExModesErrorEnum)) {
			// in case someone calls constructor without new keyword (e.g. var c = Constructor({..}))
			return new SetExModesErrorEnum(settings);
		}

		/**
		 * Used for serialization.
		 * @name SetExModesErrorEnum#_typeName
		 * @type String
		 * @readonly
		 */
		Object.defineProperty(this, "_typeName", {
			enumerable : true,
			value : "joynr.de.bmw.infotainment.telematic.applications.ConnectedMusic.SetExModesErrorEnum"
		});

		if (settings !== undefined) {
			this.name = settings.name;
			this.value = settings.value;
		}

	};

	/**
	 * @name SetExModesErrorEnum#MAJOR_VERSION
	 * @constant {Number}
	 * @default 0
	 * @summary The MAJOR_VERSION of the enum type SetExModesErrorEnum is GENERATED FROM THE INTERFACE DESCRIPTION
	 */
	Object.defineProperty(SetExModesErrorEnum, 'MAJOR_VERSION', { value: 0 });
	/**
	 * @name SetExModesErrorEnum#MINOR_VERSION
	 * @constant {Number}
	 * @default 0
	 * @summary The MINOR_VERSION of the enum type SetExModesErrorEnum is GENERATED FROM THE INTERFACE DESCRIPTION
	 */
	Object.defineProperty(SetExModesErrorEnum, 'MINOR_VERSION', { value: 0 });

	var preparePrototype = function(joynr) {
		joynr.util.GenerationUtil.addEqualsEnum(SetExModesErrorEnum);
	};
	var createLiterals = function() {
		/**
		 * @name SetExModesErrorEnum.APP_ERROR
		 * @readonly
		 */
		SetExModesErrorEnum.APP_ERROR = new SetExModesErrorEnum({
			name: "APP_ERROR",
			value: "APP_ERROR"
		});
		/**
		 * @name SetExModesErrorEnum.WRONG_INPUT
		 * @readonly
		 */
		SetExModesErrorEnum.WRONG_INPUT = new SetExModesErrorEnum({
			name: "WRONG_INPUT",
			value: "WRONG_INPUT"
		});
		/**
		 * @name SetExModesErrorEnum.PLAYLIST_NOT_AVAILABLE
		 * @readonly
		 */
		SetExModesErrorEnum.PLAYLIST_NOT_AVAILABLE = new SetExModesErrorEnum({
			name: "PLAYLIST_NOT_AVAILABLE",
			value: "PLAYLIST_NOT_AVAILABLE"
		});
		/**
		 * @name SetExModesErrorEnum.PLAYLIST_NOT_DOWNLOADED
		 * @readonly
		 */
		SetExModesErrorEnum.PLAYLIST_NOT_DOWNLOADED = new SetExModesErrorEnum({
			name: "PLAYLIST_NOT_DOWNLOADED",
			value: "PLAYLIST_NOT_DOWNLOADED"
		});
	};

	var joynr = require("joynr");
	SetExModesErrorEnum.prototype = new joynr.JoynrObject();
	SetExModesErrorEnum.prototype.constructor = SetExModesErrorEnum;
	preparePrototype(joynr);
	createLiterals();
	joynr.addType("joynr.de.bmw.infotainment.telematic.applications.ConnectedMusic.SetExModesErrorEnum", SetExModesErrorEnum, true);
	module.exports = SetExModesErrorEnum;
})();
