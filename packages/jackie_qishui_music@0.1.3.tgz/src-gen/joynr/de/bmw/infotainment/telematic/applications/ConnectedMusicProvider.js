/*
 * PLEASE NOTE. THIS IS A GENERATED FILE!
 * Generation date: Fri Jul 26 09:18:34 UTC 2019
 */
(function(undefined){

	var checkImpl = function() {
		var missingInImplementation = [];
		if (! this.loggedIn.check()) missingInImplementation.push("Attribute:loggedIn");
		if (! this.shuffle.check()) missingInImplementation.push("Attribute:shuffle");
		if (! this.setExModes.checkOperation())  missingInImplementation.push("Operation:setExModes");
		if (! this.setShuffle.checkOperation())  missingInImplementation.push("Operation:setShuffle");

		return missingInImplementation;
	};

	/**
	 * @name ConnectedMusicProvider
	 * @constructor
	 *
	 * @classdesc
	 * PLEASE NOTE. THIS IS A GENERATED FILE!
	 * <br/>Generation date: Fri Jul 26 09:18:34 UTC 2019
	 *
	 * @summary Constructor of ConnectedMusicProvider object
	 *
	 * @param {Object} [implementation] the implementation of the service-provider
	 * @param {Object} [implementation.ATTRIBUTENAME] the definition of attribute implementation
	 * @param {Function} [implementation.ATTRIBUTENAME.set] the getter function with the
	 *     signature "function(value){}" that stores the given attribute value
	 * @param {Function} [implementation.ATTRIBUTENAME.get] the getter function with the
	 *     signature "function(){}" that returns the current attribute value
	 * @param {Function} [implementation.OPERATIONNAME] the operation function
	 * @param {Object} [implementation.EVENTNAME] the definition of the event implementation
	 *
	 * @returns {ConnectedMusicProvider} a ConnectedMusicProvider object to communicate with the joynr infrastructure
	 */
	var ConnectedMusicProvider = null;
	ConnectedMusicProvider = function ConnectedMusicProvider(
		passedImplementation,
		dependencies
	) {
		if (!(this instanceof ConnectedMusicProvider)) {
			// in case someone calls constructor without new keyword (e.g. var c = Constructor({..}))
			return new ConnectedMusicProvider(
				passedImplementation,
				dependencies);
		}

		var implementation = passedImplementation || {};

		// defining service-provider members
		/**
		 * @name ConnectedMusicProvider#loggedIn
		 * @summary The loggedIn attribute is GENERATED FROM THE INTERFACE DESCRIPTION
		 */
		this.loggedIn = new dependencies.ProviderAttribute
			(this, implementation.loggedIn, "loggedIn", "Boolean", "NOTIFYREAD");
		if (implementation.loggedIn) {
			implementation.loggedIn.valueChanged = this.loggedIn.valueChanged;
		}
		/**
		 * @name ConnectedMusicProvider#shuffle
		 * @summary The shuffle attribute is GENERATED FROM THE INTERFACE DESCRIPTION
		 */
		this.shuffle = new dependencies.ProviderAttribute
			(this, implementation.shuffle, "shuffle", "Boolean", "NOTIFYREAD");
		if (implementation.shuffle) {
			implementation.shuffle.valueChanged = this.shuffle.valueChanged;
		}
		/**
		 * @function ConnectedMusicProvider#setExModes
		 * @summary The setExModes operation is GENERATED FROM THE INTERFACE DESCRIPTION
		 * <br/><br/>Method to start playback by C-Music
		 *
		 * @param {Object} settings the arguments object for this function call
		 * @param {Exmode} settings.exmode -
		 * @param {Boolean} settings.hmiExpected -
		 */
		this.setExModes = new dependencies.ProviderOperation(this, implementation.setExModes, "setExModes", [
			{
				inputParameter: [
					{
						name : "exmode",
						type : "joynr.de.bmw.infotainment.telematic.applications.ConnectedMusicTypes.Exmode",
						javascriptType : "joynr.de.bmw.infotainment.telematic.applications.ConnectedMusicTypes.Exmode"
					},
					{
						name : "hmiExpected",
						type : "Boolean",
						javascriptType : "boolean"
					}
				],
				error: {
					type: "joynr.de.bmw.infotainment.telematic.applications.ConnectedMusic.SetExModesErrorEnum"
				},
				outputParameter: [
				]
			}
		]);
		/**
		 * @function ConnectedMusicProvider#setShuffle
		 * @summary The setShuffle operation is GENERATED FROM THE INTERFACE DESCRIPTION
		 *
		 * @param {Object} settings the arguments object for this function call
		 * @param {Boolean} settings.shuffleEnabled -
		 */
		this.setShuffle = new dependencies.ProviderOperation(this, implementation.setShuffle, "setShuffle", [
			{
				inputParameter: [
					{
						name : "shuffleEnabled",
						type : "Boolean",
						javascriptType : "boolean"
					}
				],
				error: {
					type: "no error enumeration given"
				},
				outputParameter: [
				]
			}
		]);

		Object.defineProperty(this, 'checkImplementation', { value: checkImpl});

		this.interfaceName = "de/bmw/infotainment/telematic/applications/ConnectedMusic";

		return Object.freeze(this);
	};

	/**
	 * @name ConnectedMusicProvider#MAJOR_VERSION
	 * @constant {Number}
	 * @default 2
	 * @summary The MAJOR_VERSION of the service-provider is GENERATED FROM THE INTERFACE DESCRIPTION
	 */
	Object.defineProperty(ConnectedMusicProvider, 'MAJOR_VERSION', { value: 2});
	/**
	 * @name ConnectedMusicProvider#MINOR_VERSION
	 * @constant {Number}
	 * @default 1
	 * @summary The MINOR_VERSION of the service-provider is GENERATED FROM THE INTERFACE DESCRIPTION
	 */
	Object.defineProperty(ConnectedMusicProvider, 'MINOR_VERSION', { value: 1});

	require("../../../../../../joynr/de/bmw/infotainment/telematic/applications/ConnectedMusicTypes/Exmode");
	require("../../../../../../joynr/de/bmw/infotainment/telematic/applications/ConnectedMusic/SetExModesErrorEnum");
	module.exports = ConnectedMusicProvider;
})();
