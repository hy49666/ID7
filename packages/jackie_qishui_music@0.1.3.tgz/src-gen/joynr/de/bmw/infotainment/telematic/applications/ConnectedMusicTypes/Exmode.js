/**
 * This is the generated enum type Exmode: DOCS GENERATED FROM INTERFACE DESCRIPTION
 * Generation date: Fri Jul 26 09:18:34 UTC 2019
 */
(function(undefined) {

	/**
	 * @namespace Exmode
	 * @classdesc
	 * This is the generated enum type Exmode: DOCS GENERATED FROM INTERFACE DESCRIPTION
	 * <br/>Generation date: Fri Jul 26 09:18:34 UTC 2019
	 *
	 * @returns {Exmode} a new instance of a Exmode
	 */
	var Exmode = function Exmode(settings){
		if (!(this instanceof Exmode)) {
			// in case someone calls constructor without new keyword (e.g. var c = Constructor({..}))
			return new Exmode(settings);
		}

		/**
		 * Used for serialization.
		 * @name Exmode#_typeName
		 * @type String
		 * @readonly
		 */
		Object.defineProperty(this, "_typeName", {
			enumerable : true,
			value : "joynr.de.bmw.infotainment.telematic.applications.ConnectedMusicTypes.Exmode"
		});

		if (settings !== undefined) {
			this.name = settings.name;
			this.value = settings.value;
		}

	};

	/**
	 * @name Exmode#MAJOR_VERSION
	 * @constant {Number}
	 * @default 0
	 * @summary The MAJOR_VERSION of the enum type Exmode is GENERATED FROM THE INTERFACE DESCRIPTION
	 */
	Object.defineProperty(Exmode, 'MAJOR_VERSION', { value: 0 });
	/**
	 * @name Exmode#MINOR_VERSION
	 * @constant {Number}
	 * @default 0
	 * @summary The MINOR_VERSION of the enum type Exmode is GENERATED FROM THE INTERFACE DESCRIPTION
	 */
	Object.defineProperty(Exmode, 'MINOR_VERSION', { value: 0 });

	var preparePrototype = function(joynr) {
		joynr.util.GenerationUtil.addEqualsEnum(Exmode);
	};
	var createLiterals = function() {
		/**
		 * @name Exmode.EXECUTIVE
		 * @readonly
		 */
		Exmode.EXECUTIVE = new Exmode({
			name: "EXECUTIVE",
			value: "EXECUTIVE"
		});
		/**
		 * @name Exmode.EXPRESSIVE
		 * @readonly
		 */
		Exmode.EXPRESSIVE = new Exmode({
			name: "EXPRESSIVE",
			value: "EXPRESSIVE"
		});
		/**
		 * @name Exmode.PRIVATE
		 * @readonly
		 */
		Exmode.PRIVATE = new Exmode({
			name: "PRIVATE",
			value: "PRIVATE"
		});
		/**
		 * @name Exmode.WELLBEING
		 * @readonly
		 */
		Exmode.WELLBEING = new Exmode({
			name: "WELLBEING",
			value: "WELLBEING"
		});
		/**
		 * @name Exmode.ELITE
		 * @readonly
		 */
		Exmode.ELITE = new Exmode({
			name: "ELITE",
			value: "ELITE"
		});
		/**
		 * @name Exmode.HONOR
		 * @readonly
		 */
		Exmode.HONOR = new Exmode({
			name: "HONOR",
			value: "HONOR"
		});
		/**
		 * @name Exmode.ROMANCE
		 * @readonly
		 */
		Exmode.ROMANCE = new Exmode({
			name: "ROMANCE",
			value: "ROMANCE"
		});
		/**
		 * @name Exmode.ELEGANCE
		 * @readonly
		 */
		Exmode.ELEGANCE = new Exmode({
			name: "ELEGANCE",
			value: "ELEGANCE"
		});
	};

	var joynr = require("joynr");
	Exmode.prototype = new joynr.JoynrObject();
	Exmode.prototype.constructor = Exmode;
	preparePrototype(joynr);
	createLiterals();
	joynr.addType("joynr.de.bmw.infotainment.telematic.applications.ConnectedMusicTypes.Exmode", Exmode, true);
	module.exports = Exmode;
})();
