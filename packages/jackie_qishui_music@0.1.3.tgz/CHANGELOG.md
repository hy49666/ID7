## 6.6.0 (Mon Sep 18 15:17:43 2023)

### bugfix:
- [OAP] Exception Prompt Optimization
- [OAPDEV-8429] [ID7][QQ] Search track list didn’t show and played after search track
- [Release] package.json and CHANGELOG for 6.5.0


## 6.5.0 (Wed Nov 16 10:50:22 2022)

### bugfix:
- [ID7][XI]Some covers are not clear and update package.json
- [QQ] Use medium covers for track and album preview.
- [QQ] Only render progress when player is visible.
- [OAP] Fix the issue some covers not clear. Optimize onClickPlayerLeftMusician and onClickPlayerLeftAlbums.
- [OAPDEV-7459] [ID7][QQ] The track is played from beginning after bus sleep
- [OAP][Xi] Use new APIs for ID7 Ximalaya OneClick
- [OAPDEV-7096][ID7][QQ]Speech"我要听音乐"can not open QQ Music
- [Fix] cleanup tmp folders of libraries
- [Release] package.json and CHANGELOG for 6.4.2


## 6.4.2 (Sun Aug 28 20:17:56 2022 -0700)

### bugfix:
- [Release] package.json and CHANGELOG for 6.4.1


## 6.4.1 (Wed Aug 24 17:40:58 2022)

### bugfix:
- [OAPDEV-6892][MGU18][2207][ID7]Ximalayas album information page is not updated in sync
- [OAPDEV-6880] APPS_Onboard_G38_ICE_CHINA:The Ximalaya page is not displayed correctly
- [Release] package.json and CHANGELOG for 6.4.0
- [HMI] Fix HMI issues and remove duplicate strings


## 6.4.0 (Fri Aug 12 11:12:57 2022)

### bugfix:
- [OAPDEV-6795][ID7][QQ]QQ music no any popup when tap the create album which is VIP track
- [OAPDEV-6663] [MGU18][MPP][2207] Unable to transfer to QQ music screen with speech
- [ID7][QQ]Click version information button can not show version
- [OAPDEV-6598] Optimized the code.
- [OAPDEV-6598] Finished the implementation that SearchMusic or PlayMusic without slot could play a playlist.
- [OAPDEV-6235] Optimized the renewContentItemUrls retry interval to 2000ms.
- [OAPDEV-6526] Fixed the issue that the data upload to Ximalaya is incorrect.
- [OAPDEV-6239] Optimized the onClickPlayerList function.
- [Script] Fix update change log script for python 3
- [OAP] Fix some potential crash issues.
- [Release] fix gulp build script
- [OAP] Fix the issue that QQMusic sub-menu cannot expand
- [OAPDEV-6167] Upgrade oap-sdk to 27.27.2.
- [OAP] Upgrade oap-sdk to 27.27.2.
- [OAP] Remove reflect-metadata.
- [OAPDEV-5868][CM_QQ][CN][2211][G08][ID7][INT][6.3.4]QQ music list display popup "without copyright", even in the "daily suggestion"
- [OAPDEV-6278] Optimized the renewContentItemUrls logic.
- [OAPDEV-6235] Optimized the logic of handling the download file url expired in 24 hours.
- [OAPDEV-5569] Fixed the issue that FBM could not open player state.
- [OAPDEV-5303] [ID7][XI]The search result show black image when search the keyword “及”
- [OAPDEV-5232] QQ music cannot play and show download failed
- [Release] Update CHANGELOG.md. Add one more bug fix.
- [OAPDEV-5225] Suddenly current playing song stopped
- [Release] package.json and CHANGELOG for 6.3.4


## 6.3.4 (Wed Jan 12 15:53:17 2022)

### bugfix:
- [OAPDEV-5243] Speech intents "上一首/下一首" don't have feedback.
- [OAPDEV-5225] Suddenly current playing song stopped


## 6.3.3 (Mon Jan 10 14:19:32 2022)

### bugfix:
- [OAPDEV-5212] The track always play from start after speech commands “上一首”
- [OAPDEV-5226] Changed the favorite tracks page size from 30 to 50.
- [OAPDEV-5217] 839961 [PC_XIMALAYA][CN][2203]On the delete History page, the tabs are not aligned
- [OAPDEV-5182] Search code optimization


## 6.3.2 (Thu Dec 16 11:13:26 2021)

### bugfix:
- [OAPDEV-5154] Workaround for the issue that some tracks with unknown album show the same big cover.
- [OAPDEV-5110] Added the renewContentItemURLS  when download failed 3 times and Optimized the code logic on the case that renewContentItemURLS failed when there is network issue.
- [OAPDEV-5095] Fix UT.
- [OAPDEV-5095] Fix the issue enter Recommendation is slow. Remove redundant request.
- [OAPDEV-5034] Added some log to track the QR code expired time.


## 6.3.0 (Wed Nov 10 10:18:16 2021)

### bugfix:
- [Release] Fix the issue that AppCockpit failed to install dependencies.
- [OAPDEV-4880] 750872 FIT_CN_G08: After changed list, the song from new list did not play.
- [OAPDEV-4840][HMI]755220-3236113 [SH][ID8][Xi][TA] Speech input '打开喜马拉雅', usecase changed to Ximalaya, but playback did not change.
- [OAPDEV-4982][ID7][XI]Active speech to say “从收藏中删除”it worked but the subscribe button status didn’t change
- [OAPDEV-4930] Raise the memory threshold-Required by OAP>=07/21
- [ID7][OAPDEV-4861][OAP-SDK]749792 FIT_CN_G08: The song picture on the right is not loaded
- [ID7][XI]Popup “目前无法建立在线连接” when quickly switch keywords in Ximalaya hot search with ZBE
- [OAP] Fix issue that Recommendation popup error System Busy on double click on GUI.


## 6.2.3 (Thu Sep 9 17:42:07 2021)

### bugfix:
- [OAP] Fix UT.
- [OAP] Unhandled Exception fould on PROD vehicles

## 6.2.2 (Wed Sep 1 16:14:31 2021)

### bugfix:
- [OAPDEV-4484] use token from backend response header
- [OAPDEV-4793] QQ music page displayed on CID and played the track in navigation page after the last track played.
- [OAP] Use imageId as collection id if collection id is null
- [OAP] Fix image download
- [OAP] Use old download url for Xi on VDT.
- [OAP] Use old download url for QQMusic on VDT


## 6.2.1 (Thu Aug 19 07:17:05 2021)

### bugfix:
- [OAPDEV-4702] Fix UT
- [OAPDEV-4710] Removed the unused mute,unmute,skipTrack related code for speech.
- [OAPDEV-4532] Finished the feature that add BMW playlist for ID7.
- [OAPDEV-4661] Analyze crash traces from app cockpit detailed stack traces
- [OAPDEV-4554] The tracks from Last Listened play from beginning but not play continually.
- [OAPDEV-4607] Fixed the issue that The animation icon freeze when QQ music song is playing.
- [OAPDEV-4408]The source option disappears when switching to QQ music.


## 6.2.0 (Tue Jun 22 01:23:16 2021)

### bugfix:
- [OAPDEV-4556] Add bug fix from ID8
- [OAPDEV-4556] [ID7][Xi]Cannot login Ximalaya account and it pops up: Online connection currently not available.
- [OAPDEV-4533] Fix UT
- [OAPDEV-4533] Add some useful files
- [OAPDEV-4533] Upgrade oap-sdk version
- [OAPDEV-4533] Fix some error
- [OAPDEV-4533] Merge latest changes
- [OAPDEV-4533] Add DUMM for QQ music to support 2 way TLS
- [OAPDEV-4466] Return error message
- [OAPDEV-4466] fix UT
- [OAPDEV-4466] Fix the issue that stopPlayback is called on STR and PLAYLIST_EMPTY is received
- [OAPDEV-4401] Fix UT
- [OAPDEV-4401] Fix a dead-lock issue
- [OAPDEV-4401] Fix UT
- [OAPDEV-4401] Remove unused code
- [OAPDEV-4401] Fix UT
- [OAPDEV-4401] Remove this.unregisterAppPrivateEntryPoint
- [OAPDEV-4401] Debunce
- [OAPDEV-4401] Reuse the entryPointExecute event, don't unregister entryPoints on every app lifecycle
- [OAPDEV-4401] Fix the issue caught an unhandled exception: TypeError: Cannot read property 'removeListener' of undefined at ProfilePresenter.unSubscribeSpeedLockChange
- [OAPDEV-4401] don't throw error:Double registration for entry point
- [OAPDEV-4327] Debug Ximalaya data return.
- [OAPDEV-4423] Fix the issue that cannot enter OneClick
- [OAP] Revert some code.
- [OAP][Xi] Fix the issue that after cold boot, OneClick playlist shows next page button.
- [OAPDEV-4347] Remove device-id when getting device-id with vin.
- [OAPDEV-4290] Fixed QQ music is displayed in English in RSE while system language in Chinese Bugs.
- [OAPDEV-4290] Fixed QQ music is displayed in English in RSE while system language in Chinese Bugs.
- [OAPDEV-3059] Restored the package-lock.json
- [OAPDEV-3059] Daily_build_210413_Version_6.2.0
- [OAPDEV-4295] ChangeYourVin.
- [OAPDEV-4295] Fix UT.
- [OAPDEV-4295] Fix UT.
- [OAPDEV-4295] Fix UT.
- [OAPDEV-4295] Fix UT.
- [OAPDEV-4295] Fix UT.
- [OAPDEV-4295] Add BMW-VIN in request header
- [OAPDEV-4262] Fix Lint issues
- [OAPDEV-4262] Call onError when callee failed.
- [OAPDEV-4262] Fix issue that row === providerUniqueId - 1
- [OAPDEV-4262] Optimize code
- [OAPDEV-4262] Optimize code
- [OAPDEV-4262] Changed the recommendation selected key to providerUniqueId.
- [OAPDEV-4262] Finished the feature that After personal radio tracks playing finished, refresh new personal radio tracks.
- [OAPDEV-4260] Add catch for setListenHistoryListText.
- [OAPDEV-4260] Trigger Jenkins.
- [OAPDEV-4260]Fixed the issue of mixed the parameters' order caused failed to render history list.


## 6.1.2 (Mon Mar 29 16:54:20 2021)

### bugfix:
- [OAPDEV-4260] set setRowCountPromise default value as null.
- [OAPDEV-4260] Move setRowCountPromise to Presenter.
- [OAPDEV-4260] Fix UT.
- [OAPDEV-4260] Use setRowCount of ID8 to ensure trigger dataRequest event.
- [OAPDEV-4260] After logout the Ximalaya, the subscribed track list cannot update.


## 6.1.1 (Mon Mar 15 14:45:05 2021)

### bugfix:
- [OAPDEV-4233]Downgrade oe-share 11.1.2


## 6.1.0 (Mon Mar 15 14:11:11 2021)

### bugfix:
- [OAPDEV-4219]Fixed oap-lint 1.7.6.
- [OAPDEV-4219]Add minPU and maxPU for "lint:manifest".
- [OAPDEV-4219]Trigger Jenkins.
- [OAPDEV-4219] Upgrade gulp V4 and corresponding migration with higher node version.
- [OAPDEV-4186] [SHK] 512788 [CM_QQ][CN]_FIT_CN_G38: QQ Music no source available after start car.
- [OAPDEV-4186] [SHK] 512788 [CM_QQ][CN]_FIT_CN_G38: QQ Music no source available after start car.
- [OAPDEV-3972] revert promiseRetry code
- [OAPDEV-3972] QQ music entry in RSE was missing in every new lifecycle
- [OAPDEV-3972] fix UT
- [OAPDEV-3972] QQ music entry in RSE was missing in every new lifecycle
- [OAPDEV-3972] QQ music entry in RSE was missing in every new lifecycle
- [OAPDEV-4166] fix usage data return failed in mostly update request issue.
- [OAPDEV-4043] unknown album use the same cover
- [OAPDEV-4043] unknown album use the same cover
- [OAPDEV-3912] The add to favourites button in function bar turns grey after switching back from Xi
- [OAPDEV-3912] The add to favourites button in function bar turns grey after switching back from Xi
- [OAPDEV-3871] Optimized the code.
- [OAPDEV-3871] Added the logic that if the currentPlayingTrackId is null, just return.
- [OAPDEV-3871] Changed the imageManager.updateResourceBuddle to HMIUtil.updateResourceBuddle.
- [OAPDEV-3871] Optimized the set favoriteTrackId code order.
- [OAPDEV-3871] Changed the setFavoriteButtonEnabled once.
- [OAPDEV-3871] Changed the setFavorite from playerStateChange tp progressChange.
- [OAPDEV-3839] Refactor set highlight logic both on Kombi and CID
- [OAPDEV-3839] Fix UT
- [OAPDEV-3839] Fix UT
- [OAPDEV-3839] Refactor set highlight logic both on Kombi and CID
- [OAPDEV-3803] fix issue of same track in different channel
- [OAPDEV-3803] refactor code
- [OAPDEV-3803] refactor code
- [OAPDEV-3803] refactor code
- [OAPDEV-3803] fix ut
- [OAPDEV-3803] There are double highlights shown at the same time in kombi list
- [OAPDEV-3797] Revert package-lock.json.
- [OAPDEV-3797] Fix package-lock.json.
- [OAPDEV-3797] Fix the issue on openning a new channel, there is NPI on the playing row of the new channel.
- [OAPDEV-3795] Fix UT.
- [OAPDEV-3795] Fix Cannot read property 'updateResources' of undefined
- [OAPDEV-3797] Double NPI on Combi issue


## 6.0.1 (Wed Dec 2 13:25:56 2020)

### bugfix:
- [OAPDEV-3777] change log
- [OAPDEV-3777] The highlight disappears when using scrolling button in MFL to scroll the kombi list
- [OAPDEV-3777] The highlight disappears when using scrolling button in MFL to scroll the kombi list
- [OAPDEV-3782] this.playerSt = undefined
- [OAPDEV-3782] Fix checksum failed issue.
- [OAPDEV-3782] Fix 2 issues. 1. Cannot read property closeState of undefined. 2. unhandled promise rejection
- [OAPDEV-3778] Remove for loop
- [OAPDEV-3778] Remove unused method updateCombiPlayerList.
- [OAPDEV-3778] Fix multiple NPI/Highlight on Kombi issue. Root cause is in ID7 mgu HMI cached size changed to 12 from previous 32 on Kombi playlist. Now we have to deal with cache update when user scroll focus on Kombi. The cache size for CID playlist is not affected, so we don't need to do it for CID.


## 6.0.0 (Thu Nov 26 05:45:44 2020)

### bugfix:
- [OAPDEV-3765] Added some log for MyMusic.
- [OAPDEV-3328] trigger ut rebuild
- [OAPDEV-3328] update getByName Object
- [OAPDEV-3328] remove useless try catch
- [OAPDEV-3328] update licenses for oap-sdk
- [OAPDEV-3328] ID7:Search Zhou1 Jie2 got an "Unknow Error" error message & Album name
- [OAPDEV-3328] ID7:Search Zhou1 Jie2 got an "Unknow Error" error message & Album name
- [OAPDEV-3683] "Recommend" had no reaction after clicked it.
- [OAPDEV-3613] QQ music playlist was not successfully created and music cannot be selected
- [OAPDEV-3606] Optimized the logout function, do some handle in stopPlayback callback.
- [OAPDEV-3606] Optimized the logout function, do some handle in stopPlayback callback.
- [OAPDEV-3606] Fixed the issue that when logout, the function stopPlayBack throw an uncaught error:optSuccess is not a function.
- [OAPDEV-3404] fix bind(this) issue on id7
- [UT] Improve branch coverage for Player and Options
- [UT] Improve Branch coverage for QQMusicApp
- [UT] Improve branch coverage for XimalayaOneClickView
- [UT] Improve branch coverage for SpeechProvider and Utils
- [UT] Improve branch coverage for QQMusic Utils.
- [OAPDEV-3301] fix save history error in id7.
- [OAPDEV-3366] Fix TypeError: Cannot read property 'toString' of undefined. ErrorManager::showErrorPopOverlay(): errorMessage: undefined
- [UT] Improve branch coverage for QQMusicSpeech and QQMusicServiceProvider.
- [UT] Improve branch coverage for XimalayaApp.
- [UT] Improve branch coverage for MyXimalaya.
- [UT] improve branch coverage for Ximalaya Player
- [UT] Improve branch coverage for XimalayaPlayerView
- [UT] Improve branch coverage for XimalayaPlayerView
- [UT] Improve branch coverage for RhmiXimalayaAlbumInfoView
- [UT] Improve Branch coverage for Profile
- [UT] Improve coverage for Branches.
- [UT] Add UT for MyXimalayaPresenter module.
- [UT] Add UT for MyXimalayaView module.
- [UT] Improve coverage to 80% for DomainApp module
- [OAPDEV-2295] add UT to MyXiModel
- [UT] Add UT for EntryPointController.
- [UT] Add UT cases for DomainApp module
- [UT] Fix lint warning.
- [UT] Add more cases.
- [UT] Improve UT coverage for Ximalaya Speech
- [UT] Add UT for UseCaseInstance
- [UT] Add UT for AdvancedMediaPlayer and Timeout
- [UT] Improve coverage of util/oe-player to larger than 80%
- [UT] Improve coverage of image-manager to larger than 80%
- [UT] Add UT for common utils
- [UT] Fix UT errors.
- [UT] Add UT for Xi category.
- [OAPDEV-3316] fix there shows vip expiration data after login by a non-vip account.
- [UT] Add UT for Ximalaya App.
- [OAPDEV-3282] Clear HMI cache in combi/hud lists on app switch
- [OAPDEV-3276] Fixed the issue that Quickly switch between Ximalaya and Radio will cause two entry point both highlighted.


## 5.0.6 (Wed Aug 26 08:11:09 2020)

### bugfix:
- [OAPDEV-3274] Fixed the issue that Recommendation could not be entered in.
- [OAPDEV-3271] fix crash when click bestMatch during searching situation.
- [OAPDEV-3059]Daily_build_20200827
- [OAPDEV-3261] Fixed [SHK]301393560 [Single Event] [CM_QQ][CN][INT][1120][G2x] The track cannot be switched via CID touch MFL button.
- [OAPDEV-3059] Daily_build_20200826
- [OAPDEV-3268] Added the error overlay when session expired in getData() function.
- [OAPDEV-3262] Added UT cases for QQ Category.
- [OAPDEV-3263] Added UT cases for QQ Recommendation.
- [OAPDEV-3059] Daily_build_20200825
- [OAPDEV-3249] Fixed [ID7][QQ][TA] The big cover is still shown as the last one when using i-speech to say "Play Bao3ma3".
- [OAPDEV-3059]Daily_build_20200824
- [OAPDEV-3059]Daily_build_20200821
- [Xi] Remove the deprecated online payment feature.
- [UT] Remove unused code.
- [UT] Add UT for Xi Profile.
- [OAPDEV-3059]Daily_build_20200820
- [OAPDEV-3217] Changed a line of log.
- [OAPDEV-3217] Added a line of log.
- [OAPDEV-3217] Added optimizing for the player click function and fixed the issue that open a new playlist,befort new track play, if switch track, the cover does not change.
- [OAPDEV-3222] Deleted PlayerModel.playingPageTracks = [] in PlayerPresenter.ts.
- [OAPDEV-3222] Fixed enter recommendations sometimes have not correct error pop bugs.
- [UT] Add UT for Xi Utils and remove some unused code
- [OAPDEV-3216] Fixed [QQ] [ID7] Say "wo xiang ting BAO MA" via speech, the first song in the refreshed playlist is highlighted while playback is playing previous song.
- [OAPDEV-3223] Added log for the updateCoverArt function in PlayerViewManager.
- [OAPDEV-3059]Daily_build_20200819
- [OAPDEV-3169] Some code optimization
- [OAPDEV-3169] enable list when got empty tracks from backend
- [OAPDEV-3169] Change parent state before open state
- [OAPDEV-3169] Fix sendCachedUpdates failed due to INVALID_MODELID


## 5.0.5 (Tue Aug 18 11:07:55 2020)

### bugfix:
- [OAPDEV-3181] fix jenkins failed.
- [OAPDEV-3181] fix ut failed.
- [OAPDEV-3181] fix search history blank line
- [OAPDEV-3184] Changed SID SID_RHMI_ENT_SEARCH_QQ_GET_DATA_FAILED to SID_RHMI_ENT_OCCURRED_998_ERROR.
- [Xi] Add UT for XimalayaSpeechEventHandler
- [Xi] Fix UT
- [Xi] GetChannels don't wait for setDefaultView
- [Xi] Fix UT
- [Xi] Fix OneClick shows black screen on open up when network quality is poor
- [OAPDEV-3188] Remove unused code
- [OAPDEV-3188] Should remove download animation when status is download playable
- [OAPDEV-3184] Fixed pops up "copyright restriction" when searching "DEE" bugs.
- [OAPDEV-3185] Removed the catch in preloadFavorite function of getDataCallback.
- [OAPDEV-3185] Finished the task that Optimize the data initilizing of favorite tracks LUM.
- [OAPDEV-3059]Daily_build_20200814
- [OAPDEV-3183] Added QQRecommendationPresenter::getDataCallback() error log.
- [OAPDEV-3183] Fixed wrong Error message displayed when no network bugs.
- [OAPDEV-3181] fix search history show blank line after delete one entry
- [OAPDEV-3179] Finished the task that Optimize the groupHeader highlight for QQ and Ximalaya.


## 5.0.4 (Wed Aug 12 06:19:09 2020)

### bugfix:
- [OAPDEV-3059] Daily_build_20200812
- [OAPDEV-3138] INTENT_Ent_DeleteFromFavourites
- [OAPDEV-3138] When audio is not connected, don't proceed with AddChannel/RemoveChannel
- [OAPDEV-3108] Added getNextPlayablePage currentPage log's stringify.
- [OAPDEV-3108] Fixed IPAPresenter & QQMusicQueryCategoryData UT bugs.
- [OAPDEV-3108] Fixed QQMusicQueryCategoryData.spec.ts jest bugs.
- [OAPDEV-3108] Fixed there is no next page in Categories bugs.
- [OAPDEV-3169] Fix invalid model id issue
- [OAPDEV-2968] Fixed the issue that It takes too long time to load the content of My music.
- [OAPDEV-3059]Daily_build_20200810
- [OAPDEV-3103] Fix the issue that NPI lost after switch vehicle user. Set NPI when playerState changed (PLAY/STOP/PAUSE).
- [OAPDEV-3156] 1. clearn status data when switching app. 2. reload the page again once loading a new channel is failed.
- [OAPDEV-3153] Fix the issue that an uncaught error caused LUM failed.
- [OAPDEV-2983] Fix UT error.
- [OAPDEV-2983] Fix the issue "track added to playlist when it is stopped"
- [OAPDEV-3059]Daily_build_20200807.
- [OAPDEV-3059]Daily_build_20200806
- [OAPDEV-3128] fix album info state has blank line when no introduction text.
- [OAPDEV-3140] fix hot search no result when push category entrypoint twice quickly.
- [Xi] Add more UT cases.
- [OAPDEV-3120] Fixed the issue that QQ music entry point highlighted when playing radio after cold-boot.
- [OAPDEV-3104] Changed the number to enum type.
- [OAPDEV-3104] Fixed the issue that QQ music entry point should not be highlighted when entering media after sleep by qq music logged out status.
- [OAPDEV-3149] Fixed [Xi] [ID7] Uniform expiration date.
- [OAPDEV-3149] Fixed [Xi] [ID7] Version info in account lost.
- [OAPDEV-3135] Fixed the issue that The favorite track is grey and can't load the songs in it.
- [OAPDEV-3136] Fixed [ID7][QQ] The Last listened is not cleared when entering my music after re-login.
- [AppsManager] set lastEntryPointExecuteTime when set entryPointInExecute to true
- [AppsManager] Don't set entryPointInExecute to false on app start.
- [OAPDEV-3130] Remove lum channel from db on logout
- [OAPDEV-3132] Fix TypeError: Cannot read property 'getContentItemById' of undefined
- [Improve] change test case's time to be logger since it is failed in Jenkins.
- [OAPDEV-3059]Daily_build_20200805
- [OAPDEV-3099] fix search something through speech in speller, speller will be closed.
- [OAPDEV-3131] Fixed [ID7][QQ] There is no loading bar on the first song when entering a playlist to play.	Fixed no could not open app version view with new SDK.
- [OAPDEV-3125]Fixed the issue that Need pop up an error message when there is no network.
- [OAPDEV-2481] Updated package-lock.json
- [OAPSDK-2481] Upgraded SDK to 24.8.1
- [OAPDEV-2314] Make coverage of XimalayaPlayer to larger than 80%.
- [OAPDEV-2973] Removed currentPlayingIndex = row for click player list.
- [OAPDEV-2314] Done with XimalayaPlayerView UT. Move updateFocus to HMIUtils.
- [Improve] improve code style.
- [Improve] implement two function wrapper: 1. delay a given time and then execute a specific function. 2. If a function is called more times again during executing it, the only last call will be executed after it exits. Other calls will be ignored.
- [OAPDEV-2314] Add more test cases for XimalayaPlayerView
- [OAPDEV-2314] Add UT for XimalayaPlayerView


## 5.0.3 (Fri Jul 31 11:50:00 2020)

### bugfix:
- [OAPDEV-3112] Fixed [ID7][QQ] All the songs in the playlist can't be played when clicking them to play.
- [OAPDEV-3114] Should not pop error on there is no token when getting purchased albums.
- [OAPDEV-2292] add ut to search module.
- [OAPDEV-3086] Make code simpler
- [OAPDEV-3086] After log-out account NPI & Highlight stay on last played track before new track loaded in
- [OAPDEV-3093] Fixed the issue that QQ music entry point title is not highlighted when switching from radio to QQ music by using Mode button in MFL.
- [OAPDEV-3085]Optimized the fixing for seperating modules in MyMusic.
- [OAPDEV-3085] Finished the task that Separate each module in my music.
- [OAPDEV-3094] Menu fold up automatically when click entry point
- [OAPDEV-3087] do some improve.
- [OAPDEV-3087] fix cover change before audio switch.
- [OAPDEV-3083] Fixed the issue that When start to play another song, the downloading song downloading animation does not disappear.
- [OAPDEV-3083] Fixed the issue that The song didn't play,but NPI showed.
- [OAPDEV-3059] Daily_build_20200731_update
- [OAPDEV-3075] Added workaround on app side for main app issue - [NM][Single Event] 301379346 [CM_QQ][CN][INT][0720][G2x]QQ music entrypoint is inaccessed.
- [OAPDEV-3058] Added recover logic after STR for 301379210 [QQ]QQ music and Ximalaya cannot open.
- [OAPDEV-3059]Daily_build_20200731


## 5.0.2 (Wed Jul 29 13:04:19 2020)

### bugfix:
- [OAPDEV-3064] Reconnect audio source when app become visible and when user clicks on playlist
- [OAPDEV-3059] Changed oap-sdk to 24.8.1
- [OAPDEV-3080] Fixed [NM] 301380181 HU_MGU - [CM_QQ][CN] _FIT_CN_F44: The music play with previous cover.
- [OAPDEV-3043] Added category totalSize maximum number limit.
- [OAPDEV-3043] Fixed category search total bugs.
- [OAPDEV-1983] Added XimalayaPlayerView.ts await HMIUtils.initCombiHudIDs().
- [OAPDEV-1983] Added combi & hud playing default focus.
- [OAPDEV-2794] Added Lyrics format [**:**:***].
- [OAPDEV-3038] Added when query expiration save to login db.
- [OAPDEV-3059]Daily_build_20200729
- [OAPDEV-3006] Fix UT
- [OAPDEV-3006] Fix UT
- [OAPDEV-3006] Don't get data in updateGUI
- [OAPDEV-3079] Minor fix.
- [OAPDEV-3055] Disable buttons when clicks on NextPage/PrevPage.
- [OAPDEV-2299] Fix type mismatch issue
- [OAPDEV-2871] Fix TypeError: Cannot read property 'id' of null
- [OAPDEV-3056] Loading bar shows on a track which is not highlighted, loading bar moves with clicking other track
- [OAPDEV-2299] Typo
- [OAPDEV-1422] Fixed the issue that QQ music title is not highlighted when opening QQ music.
- [OAPDEV-1422] Fixed the issue that QQ music title is not highlighted when opening QQ music.
- [OAPDEV-1422] Fixed the issue that QQ music title is not highlighted when opening QQ music.
- [OAPDEV-1422] Fixed the issue that QQ music title is not highlighted when opening QQ music.
- [OAPDEV-2475] change variable name and return data format.
- [OAPDEV-3009] Auto flip to next page when 2 seconds left
- [Xi] Fix lint error
- [Xi] Replace magic number to constant
- [OAPDEV-3074] Fixed [SHK]301379661 HU_MGU - [PC_Ximalaya][CN][SHK] _FIT_CN_G08:Use ispeech to play music from radio, CID jump to ximalaya and then back to radio very quickly.
- [OAPDEV-2475] change variable name and return data format.
- [OAPDEV-2948] fix download error when first audio's vip_first_status is 1
- [OAPDEV-2944] do some function wrapper.
- [OAPDEV-2944] handle some errors and improve UT
- [OAPDEV-2944] fix shows two loading animation in album list.
- [OAPDEV-2944] fix there shows two loading in the album list.
- [OAPDEV-2036] Changed logic to avoid QQ music last song issue.
- [OAPDEV-3037] Added call ids for future trace.
- [OAPDEV-3047] Fixed on AdvancedMediaPlayer.proceed(99) Error in chain: Cannot read property 'message' of undefined.
- [OAPDEV-2036] Fixed on Ximalaya side 301318190 [NSHK] HU_MGU - [CN][MGU][CM_QQ] _FIT_CN_G38: The progress bar showed different progress in kombi and CID.
- [OAPDEV-2036] Fixed on QQ Music side 301318190 [NSHK] HU_MGU - [CN][MGU][CM_QQ] _FIT_CN_G38: The progress bar showed different progress in kombi and CID.
- [OAPDEV-3036] Fixed this issue also on Ximalaya side.
- [OAPDEV-3036] Fixed [ID7][QQ] The searched content is not recorded in history when searching the same content after re-login.
- [OAPDEV-2808] Fixed [NM] [11-20] 301362095 HU_MGU - [MGU][CM_QQ][OAP][2011]No songs can be searched by voice in the search music of QQ music.
- [OAPDEV-2888] Fixed [NM]301366497 HU_MGU - [MGU][CM_QQ][OAP]QQ music can be played normally but no content displayed in playlist
- [OAPDEV-3008] Fixed [ID7][QQ] The big cover is displayed as black cover after using i-speech to play songs.
- [OAPDEV-2853] Added workaround on app side.
- [OAPDEV-3007] Fixed [ID7][QQ] The playing song is not highlighted in kombi.
- [OAPDEV-3039] Added a patch for the issue that Played QQ music cannot be added to favorites.
- [OAPDEV-3039] Added a patch for the issue that Played QQ music cannot be added to favorites.
- [OAPDEV-3039] Added a patch for the issue that Played QQ music cannot be added to favorites.
- [OAPDEV-2590] Fixed the issue that The login page pops up after cold boot.
- [OAPDEV-2590] Fixed the issue that The login page pops up after cold boot.
- [OAPDEV-2755] Fixed the issue that Track time shown on CID and RSE is in different form.
- [OAPDEV-2755] Fixed the issue that Track time shown on CID and RSE is in different form.
- [OAPDEV-3059]Daily_build_20200728
- [OAPDEV-2475] change url.
- [OAPDEV-3031] fix there shows black cover after app switch from QQMusic.
- [OAPDEV-3031] fix there shows black cover after app switch from QQMusic.
- [OAPDEV-2614] fix there shows last song's progress after logout
- [OAPDEV-3050] Finished the task that Add the textwerk in build artifact for QQ app.
- [OAPDEV-2475] do some error handle.
- [OAPDEV-2299] Del unused code
- [OAPDEV-2299] Del unused code
- [OAPDEV-2299] Typo
- [OAPDEV-2292] ignore invalid time
- [OAPDEV-2292] ignore invalid time
- [OAPDEV-2292] Add types for backend data
- [OAPDEV-3006] Improve UT coverage of OneClick to larger than 90%.
- [OAPDEV-3006] return void.
- [OAPDEV-3006] Add UT.
- [OAPDEV-2475] fix play error audio when enter player from listen history
- [OAPDEV-3006] return Promise.reject when initialization failed.
- [OAPDEV-3006] return Promise.reject when initialization failed.
- [OAPDEV-3006] return Promise.reject when initialization failed.
- [OAPDEV-3006] call updateResources only once
- [OAPDEV-3006] Fix event handler failed to bind issue
- [OAPDEV-2861] Fixed the issue that The button of next page flashes in playback when logging out QQ music.


## 4.0.24 (Thu Jul 9 15:41:39 2020)

### bugfix:
- [OAPDEV-3005] directly show next page when playing the last song is finished.
- [fix/OAPDEV-3005] the next page index must be less than page total.
- [OAPDEV-3004] Fixed the issue that The NPI&Highlight get lost and the add to favorite button turns grey when playing the first song in My favorite Track for several times.
- [OAPDEV-2996] Fixed the issue that Click a song from last listened, it plays another song.
- [OAPDEV-2999] Fixed [QQ] Xi track plays on QQ music playback after cold boot.
- [OAPDEV-2995] Fixed next page all is vip song no track response bugs.
- [OAPDEV-2967] Fixed eventID undefined will cause unhandled promise rejection.
- [OAPDEV] fix: getting next recommendation page is failed after STR.
- [OAPDEV-2998] Fixed when invalid login on myMusic need logout bugs.
- [OAPDEV-2997] Fixed the issue that Click a song from last listened, it plays another song.
- [OAPDEV-2997] Fixed the issue that Click a song from last listened, it plays another song.
- [Improve] improve getDataCallback to support that the backend returns reject or error.
- [OAPDEV-2984] Make code more compact
- [OAPDEV-2984] resetCombiState should be called before new animation is set
- [OAPDEV-2984] Kombi list got lost after APP switch
- [OAPDEV-2990] ignoring the page whose tracks are all VIP.
- [OAPDEV-2978] fix click twice quickly in listen history show system busy error
- [OAPDEV-2978] fix click twice quickly in listen history show system busy error
- [OAPDEV-2974 2985 2982] 1. don/t display 'no content' when reaching the last page. 2. don't grey out the album playlist in MyMusic. 3. openPlayer returns immediately if playlist is empty.
- [OAPDEV-2965] Fixed [ID7][QQ] It only plays one song not a playlist when using i-speech to play "yong3qi4".
- [OAPDEV-2966] Changed playlist length <= QQMusicPublicValue.PLAYER_PAGE_SIZE
- [OAPDEV-2976] fixing if both two pages have only one track, the second page can't be updated on CID.
- [OAPDEV-2977] isLastPage() sould be the last page which has one playble track at least.
- [OAPDEV-2976] fixing if both two pages have only one track, the second page can't be updated on CID.
- [OAPDEV-2971] Fixed [ID7][QQ] Need handle full patch file name in removeResourceHandle.
- [OAPDEV-2691] Clear animation before setRowCount, set animation after setRowCount
- [OAPDEV-2961] Double NPI issue. NPI is not cleared when flip to a page which has a smaller row count.
- [OAPDEV-2967] Fixed the issue that QQ music can't recover and be opened after cold boot.
- [OAPDEV-2967] The QQMusic server maximum allowable value is 60. & Prevent app crash.
- [OAPDEV-2958 2959] fix UT error.
- [OAPDEV-2958 2959] 1. reset row count when loading a new playlist or displaying other page in order to redraw playlist. 2. reset animation firstly and then setRowCount in order to fix tow NPIs issue. 3. change pageChage from 5 to 7 in order that category does not fetch new data when paging up or down.
- [OAPDEV-2958 2959] 1. reset row count when loading a new playlist or displaying other page in order to redraw playlist. 2. reset animation firstly and then setRowCount in order to fix tow NPIs issue. 3. change pageChage from 5 to 7 in order that category does not fetch new data when paging up or down.
- [OAPDEV-2953] Added the PAGE_COUNT_LIMIT 60 for MyMusic function.
- [OAPDEV-2953] Added the PAGE_COUNT_LIMIT to 60 for the favorite tracks request from BE.
- [OAPDEV-2972] Finished the task that Change the updateResourceBundle with the ImageManager interface for MyMusic.
- [OAPDEV-2952] Focus is always on Next Page when speech input playing an album
- [OAPDEV-2943] fix can't save search history when twist zbe quickly.
- [OAPDEV-2857] Fixed jenkins failed.
- [OAPDEV-2857] [SH-1120] 301365259 -2963608 [CM_QQ][IPA][Experience mode][G2x][0720][INT]After mode trigger, ximalaya will play 3s before QQ music playing.
- [OAPDEV-2902] Fixed the issue that Other listen history is deleted instead of the selected one.
- [OAPDEV-2902] Fixed the issue that Other listen history is deleted instead of the selected one.
- [OAPDEV-2942] Improve code logic and typo.
- [OAPDEV-2942] Fixed [ID7][QQ] The Lyric is still for the first song when the second song is playing.
- [OAPDEV-2945] Fixed [ID7][QQ] It shows "copyright restrictions, no playable content" when entering one created playlist..
- [OAPDEV-2914] fix merge issue
- [FIX] fix unite test error.
- [OAPDEV-2914] delete parameter from pageDivide
- [Fix] Fix conflict with Development
- [OAPDEV-2941] Fix the issue that event handlers are set multi-times
- [Fix] Remove timers and wait for setRowCount to be finished before setting data
- [OAPDEV-2928] Fix no data_request issue due to row count doesn't change
- [OAPDEV-2928] Adding new event to removeEvents()
- [OAPDEV-2926] add cache to category list
- [OAPDEV-2928] HMI cached for sub-category albums list
- [OAPDEV-2931] Finished the task that add cache mode for MyMusic album.
- [OAPDEV-2910] 1. improve the solution of cached model. 2. change all pagesize to be 30. 3. ignore empty page dispalying since vip tracks.
- [Fix] Fix conflict with Development
- [OAPDEV-2876] Added debug log and change to compare track.id instead [QQ] [ID7] Loading bar and NPI show up together.
- [OAPDEV-2914] merge development to current branch
- [OAPDEV-2904] Finished the task that add the cache mode for MyMusic track.
- [OAPDEV-2915] fix ut fail and change some function parameters.
- [OAPDEV-2926] fix pageDevide error in CommonUtils
- [OAPDEV-2915] change cache in myXi
- [OAP] add cache to myXi
- [OAP] add cache to myXi
- [OAP] add cache to myXi
- [OAP] add cache to myXi
- [OAPDEV-2782] [Xi] Fix Loading is always displayed after press next page in playlist
- [Fix] Update UT cases
- [Fix] Minor fix
- [Fix] Minor fix
- [AnnouncerListView && AnnouncerAlbumListView] Remove timers and wait for setRowCount to be finished before setting data
- [AlbumListView] Remove timers and wait for setRowCount to be finished before setting data
- [Fix] Remove timers and wait for setRowCount to be finished before setting data
- [OAPDEV-2900] Fixed [ID7][QQ][TA]Track lost big cover and NPI& Highlight when playing via i-speech.
- [Fix] Fix a bug that combi failed to update
- [Fix] Remove timers
- [OAPDEV-2900] Fixed NPI and Cover missing issue.
- [OAPDEV-2644] Fix regression of OAPDEV-2644
- [OAPDEV-2913] Wait for clearPlayingAnimation to finish in updatePlayerList before calling startPreparedChannel
- [Fix] Move log printing to correct place
- [OAPDEV-2911] Fixed UT failed case.
- [OAPDEV-2749] Fixed lyrics delay issue
- [OAPDEV-2911] Fixed [NM]301369953 [Single Event]HU_MGU - [CM_QQ][CN] _FIT_CN_G08: Messy performance in QQmuisc after clicking a song in Popular chart.
- [OAPDEV-2926] fix ut error of search
- [OAPDEV-2908] Made a patch for the issue The add to favorite is always grey when playing songs.
- [OAPDEV-2914] add cache to search
- [OAPDEV-2914] add cache to search
- [Xi] Using HmiDataRequestManager.
- [Xi] Using HMI Cached for AlbumInfoView
- [OAPDEV-2910] fix the issues that  UT are failed.
- [Xi] No paging for AlbumInfoView since there is only one album in the list
- [OAPDEV-2910] 1. Implementing HmiDataRequestManger to subscribe system DATA_REQUEST for all components who need to support the cached-model in QQ and Xi. 2. Implement cached-model in player.
- [Xi] HMI Cached Player
- [OAPDEV-2903] Updated driving states from 0 to 5 km/h.
- [OAPDEV-2644] fix shows icon in combi when switch app from qq to xi


## 5.0.1 (Mon Jun 22 17:41:38 2020)

### bugfix:
- [OAPDEV-2867] Added LyricsPresenter.ts catch reject method.
- [OAPDEV-2867] Updated LyricsPresenter promise return method.
- [OAPDEV-2867] Replaced vehicleDeta Util logger type any to ILogger & added moved lyrics logger.
- [OAPDEV-2867] Added to prevent multiple clicks lyrics.
- [OAPDEV-2866] Changed logic in stop
- [OAPDEV-2866] Fixed HMI update error
- [OAPDEV-2866] Fixed [SHK]301365946 HU_MGU - HU_MGU - [CN][MGU][CM_QQ][OAP][2007] After change page, the highlight was missing in kombi
- [OAPDEV-2875] Fixed the issue that Two played highlights displayed in playlist in QQ music.


## 4.0.22 (Tue Jun 16 04:05:48 2020)

### bugfix:
- [OAPDEV-2851] Fixed the issue that QQ music does not automatically play when switch from Ximalayan to QQ music.
- [OAPDEV-2851] Fixed the issue that QQ music does not automatically play when switch from Ximalayan to QQ music.
- [OAPDEV-2851] Fixed the issue that QQ music does not automatically play when switch from Ximalayan to QQ music.
- [OAPDEV-2851] Fixed the issue that QQ music does not automatically play when switch from Ximalayan to QQ music.
- [OAPDEV-2851] Fixed the issue that QQ music does not automatically play when switch from Ximalayan to QQ music.
- [OAPDEV-2851] Fixed the issue that QQ music does not automatically play when switch from Ximalayan to QQ music.
- [OAPDEV-2850] Change on app client to avoid number>20
- [OAPDEV-2854] Revert fix for OAPDEV-2843
- [OAPDEV-2835] Added the feature Create a tool to generate a change log for release.
- [OAPDEV-2835] Added the feature Create a tool to generate a change log for release.
- [OAPDEV-2847] Fixed 301364582 [Single Event]HU_MGU - [CN][MGU][CM_QQ] _FIT_CN_G38: Other types of music have appeared in the "Years" category
- [OAPDEV-2848] Removed logout logic in getData(). Added new popup logic
- [OAPDEV-2843] Click the playing track, set play time to 0
- [OAPDEV-2843] Double click the playing track while another track is downloading will cause current playlist to stuck
- [OAPDEV-2841] [ID7][QQ] The playback is shown as black page when clicking entry point after cold boot.
- [OAPDEV-2292] fix ut error in search module
- [OAPDEV-2292] fix ut error in search module
- [OAPDEV-2292] fix ut error in search module
- [OAPDEV-2292] fix ut error in search module
- [OAPDEV-2835] Added the feature Create a tool to generate a change log for release.
- [OAPDEV-2837] Only reset playing time when the playing track is not fully downloaded
- [gulpfile] Added the script in gulpfile to create the zip package for app cockpit upload.


## 4.0.18 (Wed Jun 10 11:32:23 2020)

### bugfix:
- [Improve] improve the performance of switching app.
- [OAPDEV-2823] Use only one function to setEntryPointAvailability
- [OAPDEV-2823] Fixed [ID7][Xi] My Ximalaya can't be entered.
- [OAPDEV-2820 2818] 1. add AppState property in app in oreder that app can process any user operation only when app is in RUNNING state. 2. When app is INT_LUM mode, app will not connect audio.
- fix typo
- [OAPDEV-2813] Track couldn't be played after app switching
- [OAPDEV-2819] fix subscribe list pagination error.
- [OAPDEV-2814] Fixed the issue that Sometimes the created albums account is not correct.
- [OAPDEV-2814] Fixed the issue that Sometimes the created albums account is not correct.
- [OAPDEV-2814] Fixed the issue that Sometimes the created albums account is not correct.
- [OAPDEV-2814] Fixed the issue that Sometimes the created albums account is not correct.
- [OAPDEV-2801]Fixed the issue that Can not enter QQmusic page after QQmusic icon was lost in CID upper right corner and media list.
- [MyMusic_UT] Finished the UT for MyMusic module.


## 4.0.16 (2020/6/3)

### bugfix:
- [OAPDEV-2805] Added a reminder when the playlist return null due to QQ music delete it for recommendation.
- [OAPDEV-2804] fix the issue that LUM parameters are not restored properly.
- [OAPDEV] the lum of QQ and Xi should be launched by AppsManager ( directly launching them in initApp causes one app's lum is interrupted by another one).
- [OAPDEV-2803] fix crash in hotSearch when there is bad network.
- [OAPDEV-2803] fix crash in hotSearch when there is bad network.
- [OAPDEV-2803] fix crash in hotSearch when there is bad network.
- [OAPDEV-2632] fix usecase shutdown error
- [OAPDEV-2632] Don't block UseCase init when shutting down previous instance failed
- [OAPDEV-2778] Fixed [SHK]301360094 HU_MGU - [CN][MGU][CM_QQ][OAP][2007] After switch from Ximalaya the QQ no vioce suddenly
- [OAPDEV-2775] Fixed [SHK]301360121 [Single event]HU_MGU - [CN][MGU][CM_QQ] _FIT_CN_G38: After start the car, only two list in showed under recommendations.
- [OAPDEV-2774] Fixed some unit test failed.


## 4.0.14 (2020/5/28)

### bugfix:

- [Impove] If switching app is not completed within 10s, which mostly is caused by platform, the blocked switching will be ignored.
- [OAPDEV-2694] preclude quick enter every module double times leads to error.
- [OAPDEV-2598] fix album and announcer icon in player lost after cold boot.
- [OAPDEV-2768] Fixed the issue that The delete current track can be activated in the preview of My Favorite Track.
- [OAPDEV-2700] Remove unused parameter
- [OAPDEV-2700] Some improvements on code level
- [OAPDEV-2700] Change logic to app switch if QQ music is not running
- [OAPDEV-2763] Fixed After searched a song by speech, it showed in the list but didn't play bugs.
- [Xi] Ximalaya download animation doesn't show in time when switch tracks
- [QQ] Optimized MyMusic data init.
- [OAPDEV-2734] workaround for backend: the playlist object should be [] (not null) if total is 0.
- [OAPDEV-2609] update animations firstly and then playlist in order to draw animations on the new playlist.
- [OAPDEV-2728] Fixed the issue that The track number of My Favorite Track is changed after re-login.
- [OAPDEV-2615] Fixed lyrics cursor out of sync with song bugs.
- [OAPDEV-2610] Corrected typo in setExiting
- [OAPDEV-1413] Some improvements on code level
- [OAPDEV-1413] Fixed on Ximalaya side and app switch
- [OAPDEV-1413] Finished on QQ music side
- [OAPDEV-1413] Change to emit way in PlayEventMananger and only for running app
- [OAPDEV-1413] Fixed mute icon not work after switch track
- [OAPDEV-1413] Fixed [NSHC]301281948 -2918758-Master 2918911 HU_MGU - [CN][MGU]_FIT_CN_G05: Playing status in music album icon corresponds not to the reality
- [OAPDEV-2651] Fixed the issue that The covers in My Favorite Track, Playlist and Created Playlist can't be loaded and displayed as default cover.
- [OAPDEV-2276] Use same solution as QQMusic
- [OAPDEV-2276] 3 seconds cooling period after opening a new playlist
- [OAPDEV-2610] Revert some code
- [OAPDEV-2610] Fix some bugs
- [OAPDEV-2610] Add exiting state in child app
- [OAPDEV-2610] Don't save QQ's channel in Ximalaya's DB and vice versa
- [OAPDEV-2610] When entryPointExecute is running, reject sub-entryPoint click events
- [QQ] Optimized the initData promise set null.

4.0.12 (2020/5/20)

### bugfix:

- [QQ]Fixed the block release issue and fixed the scrollbar issue in favorite tracks preview.
- [OAPDEV-2686] Typo
- [OAPDEV-2686] Check image on disk when it's in app cache and its state is finished before download start
- [OAPDEV-2652] Fixed the issue that After press next button, the Add/Del favorite button was not update.
- [Xi] Remove unused Promise.reject()
- [OAPDEV-2652] Fixed the issue that After press next button, the Add/Del favorite button was not update.
- [OAPDEV-2588] when removing an entrypoint, it should be also removed from local cache.
- [OAPDEV-2639] Fixed view Lyrics when vehicle wait for traffic light it display "does not support automatic scrolling" bugs.
- [OAPDEV-2690] Finished the task that Add the preload for MyMusic favorite tracks preview.
- [Xi] Fix an issue in addToFav
- [Xi] Fix an issue in skip track
- [OAPDEV-2597] Fixed the issue that The next page button appears in the last page of My Favorite Track after cold boot.
- [OAPDEV-2622] Fixed the issue that All functions are not working and can't be entered after installing QQ music.
- [OAPDEV-2618] Fix this issue in XiSearch
- [OAPDEV-2618] Revert changes in EntryPointController
- [OAPDEV-2618] No response when clicked on Ximalaya search hisotry list
- [OAPDEV-2512] Fixed [ID7][QQ] The now playing song in the playlist doesn't match the song shown in the big cover.
- [OAPDEV-2507] Fixed the issue that QQ music cannot add to my favorite in My Listen after cold boot.
- [OAPDEV-2552] fix after cold boot profile name and avatar will display blank
- [OAPDEV-2630] QQMusic loaded channel of Ximalaya on Lum
- [OAPDEV-2275] make unRegisterEntryPoint running in chain
- [OAPDEV-2275] QQ can't be opened and always shows initializing when clicking on it.
- [OAPDEV-2527] Fixed [QQ] [ID7] Covers on Kombi playlist shows black
- [OAPDEV-2512] Added workaround for [ID7][QQ] The now playing song in the playlist doesn't match the song shown in the big cover.
- [OAP] upgrade oe-share to 0.5.0 which include fix for 1785,2431 and 1413
- [OAPDEV-2629] Finished the task that Add limitation for My favouite playlist and Created playlist each at most 100.
- [OAPDEV-2629] Finished the task that Add limitation for My favouite playlist and Created playlist each at most 100.
- [OAPDEV-2624] Finished the task that Change the leftIcon rendering count to 10 for every focusing on track button.
- [OAPDEV-2323] Fixed the issue that The translation status 'Delete from favourites' in QQ music is too long that cannot be fully displayed.
- [OAPDEV-2605] fix hot search preview empty leads to Xi crash
- [OAPDEV-2608] fix focus in album detail always on "subscriber(s)"
- [OAPDEV-2191] Change log level for print remove images.
- [UT] Change PlayerViewManager test case.
- [OAPDEV-2598] fix lint error
- [OAPDEV-2598] Show default album cover and icon on app start
- [OAPDEV-2598] 'Announcer' and 'Album' icon lost after cold boot


## 4.0.10 (2020/5/13)

### bugfix:

- [OAPDEV-2582] FIxed the issue that Without clicking MyMusic, The favorite track icon in toobar does not change to delete from favorite.
- [OAPDEV-2332] remove download animation when NPI is set, and when download failed/stopped/finished for tracks other than prioritized tracks
- [OAPDEV-2529] the playing animation is handled one by one when switching tracks quickly.
- [OAPDEV-2553] Replaced SID_RHMI_OE_PLAYER_QQ_PREVIOUS_PAGE zh_TW-messages.strings.
- [OAPDEV-2453] Fixed the "Next page" button is missing when switching from Xi.
- [OAPDEV-2583] Fixed the issue that Songs no small cover on History play list.
- [OAPDEV-2540] The entrypoint of QQ music and Ximalayas is missed but music can be played
- [Improve] improve the focus in playerstate and mymusic.
- [OAPDEV-2377] Fix a crash issue.
- [OAPDEV-2547] Fixed the issue that The scrollbar isn't reset to the top of the page.
- [OAPDEV-2557] Add response when adding to favorite/delete from favorite via Speech.
- [OAPDEV-2456] fix the icon in function bar highlighted even the focus is not no it
- [OAPDEV-2527] Fixed [QQ] [ID7] Covers on Kombi playlist shows black
- [OAPDEV-2556 2548] 1. open Xi's PlayerState after LUM. 2. don't call stopPlayback if app is not playing any track.
- [OAPDEV-2531] Fixed [SHK] 301350098-301349658 [Single Event][CM_QQ][INT][0720][OAP]The NPI/ album info and lyrics cannot matched with current playing track.
- [OAPDEV-2550] Fixed the 'NextPage' button should not displayed in the playlist.
- [OAPDEV-2551] Revert cleanCombi
- [OAPDEV-2535] Fixed the issue that Other track instead of the selected track is deleted when activating delete current track in Last Listened.
- [OAP] remove unused dependencies
- [OAPDEV-2366] Ximalaya logout without clear this.token
- [OAPDEV-2313] Change function name to close
- [OAPDEV-2544] fix login succeed but pop up network error.
- [OAPDEV-2431] upgrade oe-share to 0.4.0
- [OAP] Remove unused imports
- [OAP] using types in *.d.ts instead of *.js


## 4.0.8 (2020/5/6)

### bugfix:

- [OAPDEV-2505] Fixed the issue that 29 songs in favorite list disappeared after car sleeping.
- [OAPDEV-2264] Fixed 301347205-2920073-Master:2920924[ID7][QQ] After cold boot the sound button in function bar in playback get lost.
- [CI] Add Jenkinsfile to enable auto build
- [OAPDEV-2534] Fixed Chinese reminder wording is shown in english Lyrics of songs bugs.
- [OAPDEV-2503] Finished the task that Merge the tracks data and trackCovers to one data for MyMusic function.
- [OAPDEV-2422]  move the focus from the end to the head after next paging.
- [OAPDEV-2470] Fixed the focus isn't reset to the first item in Categories after re-login bugs
- [Xi] Fix lint errors
- [OAPDEV-2497] fix Search result preview is not the same as search result after click OK
- [OAPDEV-2523] [SHK]301350069 HU_MGU - [MGU][CN][CM_QQ]OAP][2007] displayed music in play list do not match the selected Category
- [OAPDEV-2494] fix sid don't change while change system language by speech.
- [OAP] TypeError: Cannot read property 'ParameterMapValueTypes' of undefined
- [OAPDEV-2431] trackLength is actually the duration of track in seconds, not the file size in bytes.
- [OAPDEV-2417] Don't flip to the next page when the last track finished playing, if failed to get tracks of the next page or if the tracks were the same as the current playing tracks.
- [OAPDEV-2504]Fixed the issue that The focus can be set on the reminder word when activating delete function in Last Listened.
- [OAPDEV-2483] fix audio failed while it's title is empty
- [Improve] continue to improve mymusic.
- [OAPDEV-2467] Fixed [SH]301347745 HU_MGU - [CN][MGU][CM_QQ][OAP][2007] After bus-sleep the QQ music cannot wrok with incorrectly playback page
- [OAPDEV-1996] Fixed the network error notification doesn't pop up when entering recommendations during network downtime bugs.
- [OAPDEV-2447] [NM]301347538 HU_MGU - [CN][MGU][CM_QQ] _FIT_CN_G08: 2 NPI from 2 songs are flashing at the same time.
- [OAPDEV-2480] Fixed the issue that Clicking a self-created playlist, it shows songs from other self-created playlist.
- [OAPDEV-2469] Fixed the issue that The artist&album info of last listened song are still shown before playing new songs after re-login.


## 4.0.6 (2020/4/27)

### bugfix:

- [OAPDEV-2443] 301335939 [QQ]Add a reminder when the fifth track finished playing in personal radio
- [Improve] improve FavoriteTracksManager.
- [OAPDEV-2459] fix kombi isn't cleared after logout
- [OAPDEV-2492] fix crash when delete search history in search module
- [OAPDEV-2292] add UT to xiAlbumListPresenter and do some optimization
- [MyMusic] continue to improve MyMusic presenter and view.
- [MyMusic] improve MyMusic presenter and view.
- [OAP] Update npm registry.
- [OAPDEV-2414] fix display defaultCover, no announcer and no albumName when enter a new album.
- [OAPDEV-2292] add UT to searchResultPresenter
- [OAPDEV-2187] Added oneclick and my ximalaya focus reset
- [OAPDEV-2448] Fixed the last line of the lyrics will repeat show at the end of the song.
- [OAPDEV-2457] Fix NPI lost issue. Save current playing page when save Lum channel.
- [OAP] upgrade oe-share to 0.3.0 and make adaptions. Change npm registry.
- [MyMusic] Added a line of log for initFavoritePlaylistId method.
- [OAPDEV-2271] [ID7][Xi] The empty kombi list can still be focused when switching from QQ music.
- [OAPDEV-2454] Fixed the issue that The played songs can't be recorded in listen history after deleting all tracks in listen history.
- [OAPDEV-2455] Fixed [ID7][QQ]login and logout will cause duplicate event triggered
- [OAP] Remove duplicated code in ImageManager
- [OAPDEV-2420] Fixed the issue that The delete current track/ all tracks are still in option menu when the Last Listened is empty.
- [OAPDEV-2266] 1. fix QQ music can't start to play automatically when switching from Xi after cold boot. 2. fix QQMusic NPI still is displaying a few seconds after paging. 3. fix QQ player state flashs badly after switching Xi to QQ. 4. improve code.
- [OAPDEV-2419] Fixed the issue that The position of Terms and Conditions in Last Listened is not correct.
- [OAPDEV-2428] Fixed QQ music lyrics cannot be loaded after I clicked mute button bugs.
- [Xi] Fix an issue that download error popup shows when the downloading track is not the track selected by user
- [Xi] Fix an issue that NPI disappears slowly when flip to next page
- [OAPDEV-2366] [Xi] logout default user when login with normal user
- [OAPDEV-2396] Fixed [ID7][QQ][TA] The covers of the songs in search result are shown as black covers.
- [OAPDEV-2346] Fixed the issue that The songs in My favorite Track appear in Last listened list without track names.
- [OAPDEV-2382] Added previous button in listen history
- [OAPDEV-2440] Fix double NPI issue. When two channels have the same track at different position, should update the playbackPosition because it changes, although the track doesn't changed.
- [OAPDEV-2395] Added error overlay for such case. Added more logs for imageManager. Fixed Search UT issue


## 4.0.4 (2020/4/15)

### bugfix:

- [OAPDEV-2378] Fixed the issue that Delete Button was not hidden when open the favorite tracks preview.
- [OAPDEV-2380] Fixed the issue that title still show the Favorite tracks when right push the ZBE in last listened button.
- [OAPDEV-2320] 2 remove error popup from xiBackend
- [OAPDEV-2320] 3 do some improves when removing error popup from xiBackend
- [OAPDEV-2334] Fixed the issue that The Version information is missing from option menu in My music.
- [OAPDEV-2246] [QQ][ID7] Paging for MyMusic.
- [OAPDEV-2364] Show default player on app start.
- [OAPDEV-2365] NPI and Highlight lost when pause/mute by FBM
- [OAPDEV-2327] Fixed the issue that The icon of My Favorite Track is still highlighted when there is no songs.
- [OAPDEV-2385] Fixed the issue that After all the last listened tracks deleted, the last listened button does not change grey and diabaled.
- [OAPDEV-1447] Fixed [ID7][QQ] Duplicated tracks appear in one album on Search side
- [OAPDEV-2320] 4 do some improves in playerPresenter when removing error popup from xiBackend
- [OAPDEV-1810] fix there shows blank player when enter player quickly two times.
- [OAPDEV-2391] Fixed the issue that Sometimes the delete favorite tracks does work.
- [OAPDEV-2375] Fixed the issue that The focus is still at My Favorite Tracks when entering My Music after re-login.
- [OAPDEV-2153] Fixed [QQ] updateResourceBundle should only be called by ImageManager
- [OAPDEV-2372] Fixed [ID7][QQ] The reminder word "无可播放内容" of VIP albums is not reasonable.
- [OAPDEV-2322] Added loading text on page buttons.
- [OAPDEV-2387] Enter oneClick twice and NPI will be missing.
- [OAPDEV-2344] Fixed the issue that The copyright restriction albums and 0 tracks albums were not filtered out.
- [OAPDEV-2349] add reminder when click oneClick channel and get empty list returned from BE.
- [OAPDEV-2347] Fixed driving car speed lock bugs & Added terms speed lock.
- [OAPDEV-2269] Fixed the issue that The album info of some tracks is empty.
- [OAPDEV-2389] fix hotwords show blank on 0720 rack.
- [OAPDEV-2360] fix there shows blank in subCategory when enter quickly at the first enter Ximalaya.
- [OAPDEV-2218] add reminder when download failed in player.
- [OAPDEV-2317] Make Lum behave the same as MusicCollection. Play in the background on app starts up, don't show player GUI. If user switches to other audio source before app starts up, just terminate Lum to avoid from interrupting user.
- [OAPDEV-2405] Fixed the issue that Listen history is empty after have listen some track.
- [OAPDEV-2344] Added the warning prompt for the albums which has copyright restriction songs.
- [OAPDEV-2292] add UT to searchHistoryPresenter
- [OAPDEV-2423] 1. don't open state for SWITCH_MODE.
- [OAPDEV-1447] [ID7][QQ] Duplicated tracks appear in one album.
- [OAPDEV-2178] Fixed focus not reset after logout issue
- [OAPDEV-2427] fix the issue that player state is blank after LUM.
- [OAPDEV-2268] [QQ][ID7][TA] Failed to Switch between QQ and Ximalaya, click QQ or Ximalaya entry point, can’t enter playback
- [OAPDEV-2137] Don't connect audio on Lum cold boot
- [OAPDEV-2376] Fixed default player shown page buttons error
- [OAPDEV-2387] Fix NPI missing when two channels have the same track at the same position.
- [OAPDEV-2427] fix QQ's blank player state when radio is running and cold boot

## 4.0.2 (2020/4/10)

### bugfix:

- [OAPDEV-2072] [OAP]301340148[QQ]Lyrics with Speedlock
- [OAPDEV-2294] [Xi]Can't click when there is no data in One Click.
- [OAPDEV-1580] [Xi][Speedlock]The T&C page can be opened when driving.
- [OAPDEV-2274] [ID7][Xi] After sleep the entry point menu of Xi can't be opened.
- [OAPDEV-2178] [HMI][SH]301334592-2895280-Master 2896402HU_MGU - [CM_QQ][MGU][OAP]Two tracks show highlight at the same time in Kombi while playing QQ music
- [OAPDEV-2108] [NM]301332481-2893251 [ID7][QQ] The use case can't be changed to QQ music when using ispeech to switch from Ximalaya to QQ music.
- [OAPDEV-2106] 301329065 [NSHK] [Single event]HU_MGU - [CN][MGU][CM_QQ] _FIT_CN_G38: "Liuxingzhishubang" & "Xingebang" lost cover, and the items under them lost small cover.
- [OAPDEV-1383] [NSHK]301281465  HU_MGU - [CN][MGU][CM_QQ] After switch the BMW account, the QQ music missing NPI and Highlight in CID and Combi
- [OAPDEV-2104] [NSHK]301329064 HU_MGU - [SHK][CN][MGU][CM_QQ] _FIT_CN_G38: QQ Music stopped after used Ximalaya.
