'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const NeteaseClient = require('./qishui-api').NeteaseClient;
const dataDir = path.resolve(__dirname, '../../data');
let client;
let pending;

function api() {
    if (!client) {
        let config = { apiBase: 'http://127.0.0.1:33632' };
        const file = path.join(dataDir, 'qishui_config.json');
        if (fs.existsSync(file)) config = Object.assign(config, JSON.parse(fs.readFileSync(file, 'utf8')));
        client = new NeteaseClient(dataDir, config);
    }
    return client;
}

function reply(returnCode, responseObject, session) {
    return JSON.stringify({ common: { returnCode, session }, responseObject });
}

async function getQrImage(args) {
    const c = api();
    const qr = await c.createQr();
    const response = await c.request('/login/qr/create', { key: qr.key, qrimg: true }, true);
    const image = response.data && response.data.qrimg;
    if (typeof image !== 'string' || !image.startsWith('data:image/png;base64,')) {
        throw new Error('Soda Music did not return a QR image');
    }
    const imageId = crypto.randomBytes(16).toString('hex');
    pending = { imageId, qr };
    return reply(0, { qrImageDO: { imageId, type: args.qqProvider, encodedImage: image.slice(22) } });
}

async function checkQr(args) {
    if (!pending || pending.imageId !== args.imageId) return reply(998);
    const request = pending;
    const c = api();
    const status = await c.checkQr(request.qr);
    if (request !== pending) return reply(998);
    if (status === 'waiting' || status === 'confirm') return reply(801);
    pending = null;
    if (status !== 'authorized') return reply(998);
    const profile = await c.profile();
    return reply(0, {
        loginResponse: {
            userInfo: { nickname: String(profile.nickname || 'Soda Music') },
            connectivityExpirationDate: Date.now()
        }
    }, 'qishui-local');
}

function cover(url, id) {
    return { url: url || '', contentType: 'image/jpeg', target: 'BON', type: 'download', size: 0, imgId: id ? String(id) : '' };
}

function collection(items, total = items.length) {
    return { objectCollection: { object: items, total } };
}

function songId(song) {
    return String(song.id);
}

async function streamMap(ids) {
    const urls = new Map();
    const valid = Array.from(new Set(ids.map(String).filter(id => /^\d+$/.test(id))));
    for (let offset = 0; offset < valid.length; offset += 30) {
        const response = await api().request('/song/url/v1', {
            id: valid.slice(offset, offset + 30).join(','), level: 'standard'
        });
        for (const item of response.data || []) urls.set(String(item.id), item);
    }
    return urls;
}

function fullUrl(stream) {
    const raw = typeof stream.url === 'string' ? stream.url : '';
    return /^https?:\/\/[a-z0-9.-]+\.music\.(126|163)\.net\//i.test(raw)
        && (!stream.freeTrialInfo || stream.freeTrialInfo === 'null')
        ? raw.replace(/^http:/, 'https:') : '';
}

async function refreshUrls(args) {
    const objects = (args.contentObjectLiteList || {}).contentObjectLite || [];
    const urls = await streamMap(objects.map(item => item.providerUniqueID));
    const contentObject = [];
    for (const item of objects) {
        const url = fullUrl(urls.get(String(item.providerUniqueID)) || {});
        if (url) contentObject.push({contentObjectLite: item, contentItem: {downloadFileURL: {url}}});
    }
    return reply(0, { contentObjectList: { contentObject } });
}

async function trackItems(songs) {
    if (!songs.length) return [];
    // These records are selectable for browsing even with playback deferred.
    return songs.map(song => {
        const album = song.al || song.album || {};
        const artists = song.ar || song.artists || [];
        const image = cover(album.picUrl, album.id || song.id);
        return {
            contentObjectLite: {
                providerUniqueID: songId(song),
                type: 'Track',
                name1: artists.map(artist => artist.name).join(' / '),
                name2: album.name || '',
                name3: song.name || '',
                songTitle: song.name || '',
                artistId: artists[0] ? String(artists[0].id) : '',
                albumId: album.id ? String(album.id) : '',
                explicitContent: false,
                playable: true,
                downloadUrl: { url: '', target: 'BON', type: 'download', size: 0, contentType: 'audio/mpeg' }
            },
            coverImageSmallUrl: image,
            coverImageMediumUrl: image,
            coverImageLargeUrl: image,
            length: Math.floor(Number(song.dt || song.duration || 0) / 1000),
            downloadable: false
        };
    });
}

function playlistItem(list, identity) {
    const id = String(list.id);
    const image = cover(list.coverImgUrl || list.picUrl, id);
    return {
        contentObjectLite: {
            providerUniqueID: identity == null ? id : String(identity),
            type: 'Playlist',
            name1: list.name || '',
            name2: identity == null ? list.name || '' : id,
            name3: list.name || '',
            playable: true
        },
        coverImageSmallUrl: image,
        coverImageMediumUrl: image,
        coverImageLargeUrl: image,
        length: Number(list.trackCount) || 0
    };
}

async function getPlaylists(created) {
    const profile = await api().profile();
    const items = [];
    for (let offset = 0; ; offset += 50) {
        const response = await api().request('/user/playlist', { uid: profile.userId, limit: 50, offset });
        const page = response.playlist || [];
        items.push(...page.filter(list => (String(list.userId) === String(profile.userId)) === created));
        if (!response.more || !page.length) break;
    }
    // The original My Music page takes its first personal playlist as Liked Songs.
    if (created) items.sort((a, b) => Number(b.specialType === 5) - Number(a.specialType === 5));
    return items.map(list => playlistItem(list));
}

function entityItem(entity, type) {
    const image = cover(entity.picUrl || entity.img1v1Url, entity.id);
    return {
        contentObjectLite: {
            providerUniqueID: String(entity.id),
            type,
            name1: type === 'Artist' ? entity.name : (entity.artist || {}).name || '',
            name2: entity.name || '',
            name3: entity.name || '',
            playable: true
        },
        coverImageSmallUrl: image, coverImageMediumUrl: image, coverImageLargeUrl: image,
        length: Number(entity.size || entity.musicSize) || 0
    };
}

function pageSize(value) {
    return Math.min(50, Math.max(1, Number(value) || 20));
}
function pageOffset(value) {
    return Math.max(0, Number(value) || 0);
}

async function playlistPage(id, offset, limit) {
    if (!/^\d+$/.test(String(id))) throw Error('Invalid playlist id');
    const [tracks, detail] = await Promise.all([
        api().request('/playlist/track/all', { id, limit, offset }),
        api().request('/playlist/detail', { id })
    ]);
    const items = await trackItems(tracks.songs || []);
    return { items, total: (detail.playlist || {}).trackCount || offset + items.length };
}

async function searchRelation(query) {
    const object = query.searchObject || {};
    const id = String(object.providerUniqueID);
    const offset = pageOffset(query.offset);
    const limit = pageSize(query.maxResultLength);
    const target = query.searchResultType;
    if (!/^\d+$/.test(id)) return {items:[],total:0};
    if (object.type === 'Playlist' && target === 'Track') return playlistPage(id, offset, limit);
    if (object.type === 'Track' && ['Album','Artist','Track'].includes(target)) {
        const song = ((await api().request('/song/detail',{ids:id})).songs || [])[0];
        if (!song) return {items:[],total:0};
        const items = target === 'Track' ? await trackItems([song]) :
            (target === 'Album' ? [song.al].filter(Boolean) : song.ar || []).map(item => entityItem(item,target));
        return {items:items.slice(offset, offset + limit),total:items.length};
    }
    if (['Album','Artist'].includes(object.type) && target === 'Track') {
        const album = object.type === 'Album';
        const response = await api().request(album ? '/album' : '/artists', {id});
        const all = (album ? response.songs : response.hotSongs) || [];
        return {items:await trackItems(all.slice(offset,offset+limit)),total:all.length};
    }
    return {items:[],total:0};
}

async function searchById(args) {
    const queries = ((args.searchRequestList || {}).searchRequest || []);
    const searchResult = await Promise.all(queries.map(async query => {
        const page = await searchRelation(query);
        return {
            searchResultType: query.searchResultType,
            totalSearchResults: page.total,
            searchResultCollection: { searchResultObject: page.items }
        };
    }));
    return reply(0, { searchResultList: { searchResult } });
}

let recommended = [];

async function recommendations() {
    let items;
    if (api().auth.cookie) {
        const result = await api().request('/recommend/resource');
        items = result.recommend;
    } else {
        const result = await api().request('/personalized',{limit:12},true);
        items = result.result;
    }
    recommended = (items || []).slice(0,12);
    return reply(0,collection(recommended.map((item,index)=>playlistItem(item,index))));
}

async function recommendedPage(args) {
    if (!recommended.length && !args.playlistId) await recommendations();
    const entry = recommended[Number(args.query)];
    const id = args.playlistId || (entry && entry.id) || args.query;
    const page = await playlistPage(id,pageOffset(args.offset),pageSize(args.maxResults));
    return reply(0,collection(page.items,page.total));
}

async function categories() {
    const response = await api().request('/playlist/catlist',{},true);
    const entries = response.sub || [];
    const order = [4,4,2,3,4,1,0];
    const channelContainer = order.map((category,index) => ({
        channelList:{channelLite:entries.filter(item=>item.category===category &&
            (index !== 4 || /\u6000\u65e7|\u7ecf\u5178|\u6821\u56ed/.test(item.name)))
            .map(item=>({name:item.name,providerUniqueID:'cat:'+item.name}))}
    }));
    return reply(0,{channelCategory:{subChannelCategoryList:{channelContainer}}});
}

async function categoryPage(args) {
    const key = String(args.playlistId || '');
    if (!key.startsWith('cat:')) return recommendedPage(args);
    const lists = await api().request('/top/playlist',{cat:key.slice(4),limit:1,order:'hot'},true);
    const list = (lists.playlists || [])[0];
    if (!list) return reply(0,collection([]));
    const page = await playlistPage(list.id,pageOffset(args.offset),pageSize(args.maxResults));
    return reply(0,collection(page.items,page.total));
}

async function downloadCover(url, directory, fallback) {
    if (!/^https:\/\/p\d+-luna\.douyinpic\.com\//i.test(url || '')) return [fallback,fallback];
    const id = crypto.createHash('sha256').update(url).digest('hex').slice(0,32);
    const data = await api().request('/cover',{url:url.replace(/^http:/,'https:')},true);
    const bytes = Buffer.from(data.image || '','base64');
    const jpeg = bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
    const png = bytes.length >= 8 && bytes.slice(0,8).toString('hex') === '89504e470d0a1a0a';
    if (!jpeg && !png) return [fallback,fallback];
    const name = 'qishui-cover-' + id + (jpeg ? '.jpg' : '.png');
    const file = path.join(directory,name);
    if (!fs.existsSync(file)) fs.writeFileSync(file,bytes,{mode:0o640});
    return [file,name];
}

async function getData(request) {
    const args = ((request.operationParameterList || {}).operationParameter || [])[0] || {};
    switch (request.operation) {
    case 'getQrImage':
        return getQrImage(args);
    case 'getQqAccessToken':
        return checkQr(args);
    case 'getLyrics':
        if (!/^\d+$/.test(String(args.trackId))) return reply(0, { lyrics: { songLyric: '' } });
        return reply(0, { lyrics: { songLyric: await api().lyrics(String(args.trackId)) } });
    case 'qqSearch': {
        const query = String(args.query || '').trim();
        if (!query) return reply(0, collection([]));
        const limit = Math.min(30, Math.max(1, Number(args.maxResults) || 20));
        const result = await api().request('/cloudsearch', {
            keywords: query, type: 1, limit, offset: Math.max(0, (Number(args.offset) || 1) - 1)
        });
        return reply(0, collection(await trackItems((result.result || {}).songs || [])));
    }
    case 'getQQRecommendation':
        return recommendations();
    case 'getQQRecommendationDetails':
        return recommendedPage(args);
    case 'getCategorizedPlaylists':
        return categories();
    case 'getCategorizedPlaylistDetails':
        return categoryPage(args);
    case 'getFavouritesPlaylist':
        return reply(0, collection(await getPlaylists(false)));
    case 'getSelfcreatedPlaylists':
        return reply(0, collection(await getPlaylists(true)));
    case 'qqSearchById':
        return searchById(args);
    case 'renewContentItemURLs':
        return refreshUrls(args);
    case 'checkFavourites': {
        const profile = await api().profile();
        const ids = new Set((await api().liked(profile.userId)).map(String));
        return reply(0, { trackIds: (args.trackIds || []).map(id => ({ trackId: id, hot: ids.has(String(id)) })) });
    }
    case 'synchroniseProfile': {
        const actions = (args.contentObjectActionList || {}).contentObjectActions || [];
        for (const action of actions) {
            const id = String((action.contentObjectLite || {}).providerUniqueID);
            if (!/^\d+$/.test(id) || !['addToFavorites','deleteFromFavorites'].includes(action.actionCode)) {
                throw new Error('Invalid Soda Music favorite action');
            }
            await api().like(id, action.actionCode === 'addToFavorites');
        }
        return reply(0, {});
    }
    default:
        throw new Error('Soda Music operation is not wired: ' + request.operation);
    }
}

function logout() {
    pending = null;
    api().logout();
}


function prepareNativeTrack(id) {
    const client = api();
    return require('./download-native-track').downloadNativeTrack({
        apiBase: client.config.apiBase, cookie: client.auth.cookie, id
    });
}

module.exports = { getData, downloadCover, logout, prepareNativeTrack };
