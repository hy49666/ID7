'use strict';

const sourceId = 1046;
const sinkId = 1024;
const fmSource = 1;
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

class NativePlayback {
    constructor() {
        this.generation = 0;
        this.queue = Promise.resolve();
    }

    serialized(action) {
        const result = this.queue.then(action);
        this.queue = result.catch(() => {});
        return result;
    }

    async start(options) {
        const generation = ++this.generation;
        await this.serialized(() => this.detach());
        if (generation !== this.generation) return false;
        const file = await options.prepare();
        let transferred = false;
        try {
            return await this.serialized(async () => {
                if (generation !== this.generation) return false;
                const [control, player] = await options.proxies();
                if (generation !== this.generation) return false;
                const front = (await control.listOfMainConnections.getValue()).filter(x => x.sinkID === sinkId);
                if (generation !== this.generation) return false;
                if (front.some(x => x.sourceID === sourceId)) throw Error('nativeAudioBusy');
                const state = await player.playerState.getValue();
                if (state !== 'PLAYER_STATE_STOP') throw Error('nativeAudioBusy');
                if (generation !== this.generation) return false;
                const route = await control.connect({ sourceID: sourceId, sinkID: sinkId }, 2500);
                if (route.amError !== 'E_OK' || !Number.isInteger(route.mainConnectionID)) throw Error('nativeAudioOutput');
                const current = {
                    id: route.mainConnectionID, control, player, file, generation, options,
                    restoreFm: front.some(x => x.sourceID === fmSource && x.connectionState === 'CS_CONNECTED')
                };
                this.current = current;
                transferred = true;
                try {
                    if (generation !== this.generation) {
                        await this.detach();
                        return false;
                    }
                    const result = await player.playFile({ path: file.file, languageCode: 7695972 }, 2500);
                    if (result.EntError !== 'OK') throw Error('nativeAudioFile');
                    const deadline = Date.now() + 5000;
                    const registrationDeadline = Date.now() + 400;
                    while (generation === this.generation && Date.now() < deadline) {
                        const connection = await this.connection(current);
                        if (!connection && Date.now() >= registrationDeadline) throw Error('nativeAudioOutput');
                        const time = await player.currentItemTime.getValue();
                        const playerState = await player.playerState.getValue();
                        if (connection && connection.connectionState === 'CS_CONNECTED' &&
                            playerState === 'PLAYER_STATE_PLAY' && time.elapsed > 0) {
                            current.started = true;
                            options.progress(time);
                            this.schedule(current);
                            return true;
                        }
                        await wait(250);
                    }
                    await this.detach();
                    if (generation === this.generation) throw Error('nativeAudioOutput');
                    return false;
                } catch (error) {
                    await this.detach();
                    throw error;
                }
            });
        } finally {
            if (!transferred) await file.release().catch(() => {});
        }
    }

    async connection(current) {
        const all = await current.control.listOfMainConnections.getValue();
        return all.find(x => x.mainConnectionID === current.id && x.sourceID === sourceId && x.sinkID === sinkId);
    }

    schedule(current) {
        current.timer = setTimeout(() => this.serialized(async () => {
            if (this.current !== current) return;
            try {
                if (!(await this.connection(current))) throw Error('nativeAudioOutput');
                const state = await current.player.playerState.getValue();
                if (state === 'PLAYER_STATE_STOP') {
                    await this.detach();
                    if (current.generation === this.generation) current.options.finished();
                    return;
                }
                if (current.generation === this.generation) current.options.progress(await current.player.currentItemTime.getValue());
                this.schedule(current);
            } catch (error) {
                await this.detach();
                if (current.generation === this.generation) current.options.failed(error);
            }
        }).catch(() => {}), 800);
    }

    async detach() {
        const current = this.current;
        if (!current) return;
        this.current = null;
        clearTimeout(current.timer);
        const { player, control, id, file, restoreFm } = current;
        try {
            const owned = await this.connection(current).catch(() => null);
            const selected = await player.currentItemPath.getValue().catch(() => null);
            if (selected === file.file || selected === 'file://' + file.file) {
                await player.sendButtonEvent({ button: 'STOP', action: 'RELEASE' }, 1800).catch(() => {});
            }
            if (owned) await control.disconnect({ mainConnectionID: id }, 2000).catch(() => {});
            if (restoreFm) {
                for (let attempt = 0; attempt < 8; attempt++) {
                    const all = await control.listOfMainConnections.getValue().catch(() => null);
                    if (!all) break;
                    const front = all.filter(x => x.sinkID === sinkId);
                    if (!front.length) {
                        await control.connect({ sourceID: fmSource, sinkID: sinkId }, 2000).catch(() => {});
                        break;
                    }
                    if (front.some(x => x.mainConnectionID !== id)) break;
                    await wait(230);
                }
            }
        } finally {
            await file.release().catch(() => {});
        }
    }

    stop() {
        this.generation++;
        return this.serialized(() => this.detach());
    }

    isConnected() {
        return Boolean(this.current && this.current.started);
    }

    button(button, action) {
        if (action !== 'RELEASE') return Promise.resolve({ EntError: 'NOT_SUPPORTED' });
        if (button === 'STOP') return this.stop().then(() => ({ EntError: 'OK' }));
        return this.serialized(async () => {
            const current = this.current;
            if (!current || !['PLAY', 'PAUSE', 'ITEM_NEXT', 'ITEM_PREV'].includes(button) || !(await this.connection(current))) {
                return { EntError: 'NOT_SUPPORTED' };
            }
            if (button === 'ITEM_NEXT' || button === 'ITEM_PREV') {
                const offset = button === 'ITEM_NEXT' ? 1 : -1;
                return { EntError: current.options.skip(offset) ? 'OK' : 'NOT_SUPPORTED' };
            }
            return current.player.sendButtonEvent({ button, action }, 2000);
        });
    }
}

module.exports = { NativePlayback, playback: new NativePlayback() };
