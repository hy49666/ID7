'use strict';

const fs = require('fs');
const http = require('http');
const https = require('https');
const path = require('path');
const { randomBytes } = require('crypto');
const { promisify } = require('util');
const { parse } = require('url');

const mkdtemp = promisify(fs.mkdtemp);
const chmod = promisify(fs.chmod);
const open = promisify(fs.open);
const read = promisify(fs.read);
const close = promisify(fs.close);
const unlink = promisify(fs.unlink);
const rmdir = promisify(fs.rmdir);

function transfer(target, body, file) {
    return new Promise((resolve, reject) => {
        let response;
        let output;
        let failure;
        const finish = error => {
            clearTimeout(deadline);
            if (error) reject(error);
            else resolve();
        };
        const fail = error => {
            if (failure) return;
            failure = error;
            if (response) response.destroy();
            request.destroy();
            if (output) output.destroy();
            else finish(error);
        };
        const request = (target.protocol === 'https:' ? https : http).request(target, incoming => {
            response = incoming;
            if (failure) return response.destroy();
            if (response.statusCode === 403) return fail(Error('该歌曲没有完整播放权限'));
            const length = Number(response.headers['content-length']);
            if (response.statusCode !== 200 || !/^audio\/mp4(?:;|$)/i.test(response.headers['content-type'] || '') ||
                !Number.isSafeInteger(length) || length < 12 || length >= 32 * 1024 * 1024) {
                return fail(Error('汽水音乐播放文件不可用'));
            }

            let received = 0;
            output = fs.createWriteStream(file, { flags: 'wx', mode: 0o600 });
            output.once('error', fail);
            output.once('close', () => finish(failure || (received !== length ? Error('播放文件未收完整') : null)));
            response.once('aborted', () => fail(Error('播放文件传输中断')));
            response.once('error', fail);
            response.on('data', chunk => {
                received += chunk.length;
                if (received > length) fail(Error('播放文件长度异常'));
            });
            response.pipe(output);
        });
        const deadline = setTimeout(() => fail(Error('准备播放文件超时')), 130000);
        request.once('error', fail);
        request.end(body);
    });
}

async function downloadNativeTrack({ apiBase, cookie, id }) {
    if (!/^\d{1,20}$/.test(String(id))) throw Error('无效的汽水音乐歌曲 ID');
    const base = parse(apiBase || '');
    const loopback = ['127.0.0.1', '::1', 'localhost'].includes(base.hostname);
    if (!base.hostname || base.auth || base.search || base.hash ||
        (base.protocol !== 'https:' && !(base.protocol === 'http:' && loopback))) {
        throw Error('播放后端地址无效');
    }
    const target = parse(apiBase.replace(/\/$/, '') + '/audio/m4a');
    const body = JSON.stringify({ id: String(id), cookie });
    target.method = 'POST';
    target.headers = { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) };

    const folder = await mkdtemp('/tmp/qishui-audio-');
    const file = path.join(folder, randomBytes(16).toString('hex') + '.m4a');
    async function release() {
        try { await unlink(file); } catch (error) { if (error.code !== 'ENOENT') throw error; }
        try { await rmdir(folder); } catch (error) { if (error.code !== 'ENOENT') throw error; }
    }
    try {
        await transfer(target, body, file);
        const descriptor = await open(file, 'r');
        try {
            const header = Buffer.alloc(12);
            await read(descriptor, header, 0, header.length, 0);
            if (header.toString('ascii', 4, 8) !== 'ftyp') throw Error('播放文件不是有效的 M4A');
        } finally {
            await close(descriptor);
        }
        await chmod(file, 0o444);
        await chmod(folder, 0o711);
        return { file, release };
    } catch (error) {
        await release().catch(() => {});
        throw error;
    }
}

module.exports = { downloadNativeTrack };
