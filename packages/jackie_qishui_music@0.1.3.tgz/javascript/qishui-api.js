'use strict';
// SPDX-License-Identifier: GPL-3.0-or-later
const fs = require('fs');
const path = require('path');
const url = require('url');
const http = require('http');
const https = require('https');
function save(file, value) {
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(value), { mode: 0o600 });
    fs.renameSync(tmp, file);
}
function read(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (_) { return fallback; } }
function track(t) {
    return { id: String(t.id), title: t.name || '', artist: (t.ar || t.artists || []).map(a => a.name).join(' / '),
        album: (t.al || t.album || {}).name || '', albumArt: (t.al || t.album || {}).picUrl || '', durationMs: t.dt || t.duration || 0 };
}
class NeteaseClient {
    constructor(dataDir, config, transport) {
        this.file = path.join(dataDir, 'qishui_auth.json');
        this.auth = read(this.file, {});
        this.config = config;
        this.transport = transport;
        this.generation = 0;
    }
    async request(endpoint, args, anonymous) {
        if (!/^\/[a-z0-9_/]+$/.test(endpoint)) throw new Error('Invalid API endpoint');
        const parsed = url.parse(this.config.apiBase || '');
        const local = ['127.0.0.1', '::1', 'localhost'].indexOf(parsed.hostname) >= 0;
        if (!parsed.hostname || parsed.auth || parsed.search || parsed.hash ||
            (parsed.protocol !== 'https:' && !(parsed.protocol === 'http:' && local))) {
            throw new Error('请在配置中填写 HTTPS apiBase（本机测试允许 loopback HTTP）');
        }
        const body = Object.assign({}, args || {}, { timestamp: Date.now() });
        if (!anonymous && this.auth.cookie) body.cookie = this.auth.cookie;
        const target = this.config.apiBase.replace(/\/$/, '') + endpoint;
        if (this.transport) return this.transport(target, body);
        return new Promise((resolve, reject) => {
            const data = JSON.stringify(body);
            const opts = url.parse(target);
            opts.method = 'POST';
            opts.headers = { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) };
            const req = (opts.protocol === 'https:' ? https : http).request(opts, res => {
                let text = '', count = 0;
                res.on('data', part => {
                    count += part.length;
                    if (count > 8 * 1024 * 1024) { res.destroy(); reject(new Error('API response too large')); return; }
                    text += part;
                });
                res.on('error', () => reject(new Error('API response interrupted')));
                res.on('end', () => {
                    if (res.statusCode < 200 || res.statusCode >= 300) return reject(new Error('API HTTP ' + res.statusCode));
                    try {
                        const result = JSON.parse(text);
                        if (Number(result.code) === 301) return reject(new Error('登录已过期，请重新扫码'));
                        if (result.code && Number(result.code) !== 200 && endpoint.indexOf('/login/qr/') !== 0) return reject(new Error('汽水音乐接口状态 ' + result.code + (result.message ? '：' + String(result.message).slice(0, 120) : '')));
                        resolve(result);
                    } catch (_) { reject(new Error('API did not return valid JSON')); }
                });
            });
            const timer = setTimeout(() => { req.destroy(); reject(new Error('API timeout')); }, 15000);
            const done = () => clearTimeout(timer);
            req.on('error', () => { done(); reject(new Error('API connection failed')); });
            req.on('close', done);
            req.end(data);
        });
    }
    async createQr() {
        const key = await this.request('/login/qr/key', {}, true);
        if (!key.data || !key.data.unikey) throw new Error('无法生成登录 key');
        const qr = await this.request('/login/qr/create', { key: key.data.unikey, qrimg: false }, true);
        if (!qr.data || !/^https:\/\/music\.douyin\.com\//.test(qr.data.qrurl || '')) throw new Error('无效的汽水音乐登录二维码');
        this.qr = { key: key.data.unikey, url: qr.data.qrurl, generation: this.generation };
        return this.qr;
    }
    async checkQr(qr) {
        if (!qr || qr.generation !== this.generation) return 'cancelled';
        const r = await this.request('/login/qr/check', { key: qr.key }, true);
        if (qr.generation !== this.generation) return 'cancelled';
        if (r.code === 803) {
            if (!r.cookie || typeof r.cookie !== 'string') throw new Error('扫码成功但没有返回登录会话');
            this.auth = { cookie: r.cookie };
            save(this.file, this.auth);
            return 'authorized';
        }
        if (r.code === 800) return 'expired';
        if (r.code !== 801 && r.code !== 802) throw new Error('扫码状态异常 ' + r.code);
        return r.code === 802 ? 'confirm' : 'waiting';
    }
    async profile() {
        const r = await this.request('/login/status');
        const p = (r.data || {}).profile;
        if (!p || !p.userId) throw new Error('请先扫码登录汽水音乐');
        return p;
    }
    async playlists(uid, offset) {
        const r = await this.request('/user/playlist', { uid: uid, limit: 30, offset: offset || 0 });
        return { items: (r.playlist || []).map(p => ({ id: String(p.id), title: p.name, count: p.trackCount, cover: p.coverImgUrl })), more: !!r.more };
    }
    async tracks(id, offset) {
        const r = await this.request('/playlist/track/all', { id: id, limit: 30, offset: offset || 0 });
        return (r.songs || []).map(track);
    }
    async liked(uid) {
        const r = await this.request('/likelist', { uid: uid });
        return (r.ids || []).map(String);
    }
    async details(ids) {
        if (!ids.length) return [];
        const r = await this.request('/song/detail', { ids: ids.join(',') });
        return (r.songs || []).map(track);
    }
    async search(keywords, offset) {
        const r = await this.request('/cloudsearch', { keywords: keywords, type: 1, limit: 30, offset: offset || 0 });
        return { items: ((r.result || {}).songs || []).map(track), total: (r.result || {}).songCount || 0 };
    }
    async lyrics(id) { const r = await this.request('/lyric', { id: id }); return (r.lrc || {}).lyric || ''; }
    async stream(id) {
        const r = await this.request('/song/url/v1', { id: id, level: this.config.quality || 'standard' });
        const s = (r.data || [])[0];
        if (!s || !s.url) throw new Error('该歌曲暂不可播，请检查账号权限、版权或接口状态');
        if (s.freeTrialInfo && s.freeTrialInfo !== 'null') throw new Error('接口只返回试听片段，未作为完整歌曲播放');
        const p = url.parse(s.url);
        if (p.protocol === 'http:' && /(^|\.)music\.(126|163)\.net$/.test(p.hostname || '') && !p.auth) {
            s.url = s.url.replace(/^http:/, 'https:'); p.protocol = 'https:';
        }
        if (p.protocol !== 'https:' || !p.hostname || p.auth) throw new Error('拒绝非 HTTPS 音频地址');
        return s.url;
    }
    async like(id, value) { await this.request('/like', { id: id, like: value }); }
    logout() {
        this.generation++;
        this.auth = {};
        this.qr = null;
        if (fs.existsSync(this.file)) fs.unlinkSync(this.file);
    }
}
module.exports = { NeteaseClient, track, read, save };
